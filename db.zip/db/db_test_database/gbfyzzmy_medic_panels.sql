-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Apr 24, 2020 at 04:41 PM
-- Server version: 5.7.29
-- PHP Version: 7.2.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `gbfyzzmy_medic_panels`
--
CREATE DATABASE IF NOT EXISTS `gbfyzzmy_medic_panels` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `gbfyzzmy_medic_panels`;

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`gbfyzzmy_m_p_adm`@`%` PROCEDURE `sp_create_answers_for_questions` (IN `text` VARCHAR(255), IN `questions_id` INT)  begin
	DECLARE in_sql MEDIUMTEXT;
    SET @text = text;
    SET @questions_id = questions_id;

	SET in_sql = "INSERT INTO gbfyzzmy_medic_panels.question_answers(text,option_value,questions_id)
    VALUES(@text,'option_value_novi',@questions_id);";
	SET @sqlv = in_sql;
    PREPARE stmt FROM @sqlv;
    EXECUTE stmt;
    DEALLOCATE PREPARE stmt;
    
    SET in_sql = "SELECT LAST_INSERT_ID() as 'last_answer_id';";
	SET @sqlv = in_sql;
    PREPARE stmt FROM @sqlv;
    EXECUTE stmt;
    DEALLOCATE PREPARE stmt;

end$$

CREATE DEFINER=`gbfyzzmy_m_p_adm`@`%` PROCEDURE `sp_create_new_panel` (IN `panel_name` VARCHAR(255))  begin
	DECLARE in_sql MEDIUMTEXT;
    
    SET @panel_name = panel_name;
    
	SET in_sql =  "INSERT INTO gbfyzzmy_medic_panels.surv_survey_panels(panel_name, surv_survey_id) VALUES(@panel_name, 1)";
	SET @sqlv = in_sql;
    PREPARE stmt FROM @sqlv;
    EXECUTE stmt;
    DEALLOCATE PREPARE stmt;
 
end$$

CREATE DEFINER=`gbfyzzmy_m_p_adm`@`%` PROCEDURE `sp_create_patient` (IN `firstName` VARCHAR(255), IN `lastName` VARCHAR(255), IN `oib` VARCHAR(11), IN `mbo` VARCHAR(9), IN `age` INT, IN `gender` VARCHAR(255), IN `email` VARCHAR(255), IN `phoneNumber` INT, IN `city` VARCHAR(255), IN `address` VARCHAR(255), IN `zip` INT)  begin
	DECLARE in_sql MEDIUMTEXT;
    
	SET in_sql = "SELECT NOW()  INTO @date_submitted;";
    SET @sqlv = in_sql;
    PREPARE stmt FROM @sqlv;
    EXECUTE stmt;
    DEALLOCATE PREPARE stmt;
    
	SET @firstName = firstName;
	SET @lastName = lastName;
	SET @oib = oib;
	SET @mbo = mbo;
	SET @age = age;
	SET @gender = gender;
	SET @email = email;
	SET @phoneNumber = phoneNumber;
	SET @city = city;
	SET @address = address;
	SET @zip = zip;
    
   SET in_sql =  "INSERT INTO gbfyzzmy_medic_panels.patient(firstName, lastName, oib, mbo, age,gender,email,phoneNumber, city, address, zip, date_patient_created) 
   VALUES(@firstName, @lastName, @oib, @mbo, @age,@gender,@email,@phoneNumber, @city, @address, @zip, @date_submitted);";
   SET @sqlv = in_sql;
    PREPARE stmt FROM @sqlv;
    EXECUTE stmt;
    DEALLOCATE PREPARE stmt;
 
end$$

CREATE DEFINER=`gbfyzzmy_m_p_adm`@`%` PROCEDURE `sp_create_pharmacist` (IN `name` VARCHAR(255), IN `email` VARCHAR(255), IN `username` VARCHAR(255), IN `password` MEDIUMTEXT, IN `pharmacy_id` INT)  begin
	DECLARE in_sql MEDIUMTEXT;
    
    SET @name = name;
    SET @email = email;
	SET @username = username;
   	SET @password = password;
    SET @pharmacy_id = pharmacy_id;

    SET in_sql = "INSERT INTO gbfyzzmy_medic_panels.pharmacist(name, role, user_credentials_id,pharmacy_id) VALUES( @name, 'admin' ,1,@pharmacy_id);";
    SET @sqlv = in_sql;
    PREPARE stmt FROM @sqlv;
    EXECUTE stmt;
    DEALLOCATE PREPARE stmt;
    
    SET in_sql = "SELECT LAST_INSERT_ID()  INTO @user_id;";
    SET @sqlv = in_sql;
    PREPARE stmt FROM @sqlv;
    EXECUTE stmt;
    DEALLOCATE PREPARE stmt;
    
	SET in_sql = "INSERT INTO  gbfyzzmy_medic_panels.user_credentials
        (username, password, email, user_id)
        VALUES(@username, @password, @email, @user_id)";

    SET @sqlv = in_sql;
    PREPARE stmt FROM @sqlv;
    EXECUTE stmt;
    DEALLOCATE PREPARE stmt;

end$$

CREATE DEFINER=`gbfyzzmy_m_p_adm`@`%` PROCEDURE `sp_delete_label` (IN `label_id` INT)  begin
	DECLARE in_sql MEDIUMTEXT;
    
	SET @label_id = label_id;
    
    SET in_sql = "DELETE FROM gbfyzzmy_medic_panels.surv_panel_labels_questions WHERE id = @label_id;";
	SET @sqlv = in_sql;
    PREPARE stmt FROM @sqlv;
    EXECUTE stmt;
    DEALLOCATE PREPARE stmt;

end$$

CREATE DEFINER=`gbfyzzmy_m_p_adm`@`%` PROCEDURE `sp_delete_panel_by_id` (IN `panel_id` INT)  begin
	DECLARE in_sql MEDIUMTEXT;
    
    SET @panel_id = panel_id;
    
	SET in_sql =  "DELETE FROM gbfyzzmy_medic_panels.surv_panel_questions WHERE surv_survey_panels_id = @panel_id;";
	SET @sqlv = in_sql;
    PREPARE stmt FROM @sqlv;
    EXECUTE stmt;
    DEALLOCATE PREPARE stmt;
    
    SET in_sql =  "DELETE FROM gbfyzzmy_medic_panels.surv_panel_labels_questions WHERE surv_survey_panels_id = @panel_id;";
	SET @sqlv = in_sql;
    PREPARE stmt FROM @sqlv;
    EXECUTE stmt;
    DEALLOCATE PREPARE stmt;
    
     SET in_sql =  "DELETE FROM gbfyzzmy_medic_panels.surv_survey_panels WHERE id = @panel_id;";
	SET @sqlv = in_sql;
    PREPARE stmt FROM @sqlv;
    EXECUTE stmt;
    DEALLOCATE PREPARE stmt;
 
end$$

CREATE DEFINER=`gbfyzzmy_m_p_adm`@`%` PROCEDURE `sp_delete_patient_by_id` (IN `patient_id` INT)  begin
	DECLARE in_sql MEDIUMTEXT;
    
    SET @patient_id = patient_id;
    
    SET SQL_SAFE_UPDATES = 0;


	SET in_sql =  "DELETE FROM gbfyzzmy_medic_panels.patient_answers WHERE id_patient = @patient_id;";
	SET @sqlv = in_sql;
    PREPARE stmt FROM @sqlv;
    EXECUTE stmt;
    DEALLOCATE PREPARE stmt;
    
	SET SQL_SAFE_UPDATES = 1;

	SET in_sql =  "DELETE FROM gbfyzzmy_medic_panels.patient_record_history WHERE patient_id = @patient_id;";
	SET @sqlv = in_sql;
    PREPARE stmt FROM @sqlv;
    EXECUTE stmt;
    DEALLOCATE PREPARE stmt;
    
    
    SET in_sql =  "DELETE FROM gbfyzzmy_medic_panels.patient WHERE id = @patient_id;";
	SET @sqlv = in_sql;
    PREPARE stmt FROM @sqlv;
    EXECUTE stmt;
    DEALLOCATE PREPARE stmt;
 
end$$

CREATE DEFINER=`gbfyzzmy_m_p_adm`@`%` PROCEDURE `sp_delete_question_by_id` (IN `question_id` INT)  begin
	DECLARE in_sql MEDIUMTEXT;
    
    SET @question_id = question_id;
    
	SET in_sql = "DELETE FROM gbfyzzmy_medic_panels.question_answers WHERE questions_id = @question_id;";
	SET @sqlv = in_sql;
    PREPARE stmt FROM @sqlv;
    EXECUTE stmt;
    DEALLOCATE PREPARE stmt;
    
    SET in_sql = "DELETE FROM gbfyzzmy_medic_panels.surv_panel_questions WHERE id = @question_id;";
	SET @sqlv = in_sql;
    PREPARE stmt FROM @sqlv;
    EXECUTE stmt;
    DEALLOCATE PREPARE stmt;
    
	SET in_sql = "DELETE FROM gbfyzzmy_medic_panels.questions WHERE id = @question_id;";
	SET @sqlv = in_sql;
    PREPARE stmt FROM @sqlv;
    EXECUTE stmt;
    DEALLOCATE PREPARE stmt;

end$$

CREATE DEFINER=`gbfyzzmy_m_p_adm`@`%` PROCEDURE `sp_delete_record_by_id` (IN `record_id` INT)  begin
	DECLARE in_sql MEDIUMTEXT;
    
    SET @record_id = record_id;
    
	SET in_sql =  "DELETE FROM gbfyzzmy_medic_panels.patient_answers WHERE id_patient_record_history = @record_id;";
	SET @sqlv = in_sql;
    PREPARE stmt FROM @sqlv;
    EXECUTE stmt;
    DEALLOCATE PREPARE stmt;
    
    SET in_sql =  "DELETE FROM gbfyzzmy_medic_panels.patient_record_history WHERE id = @record_id;";
	SET @sqlv = in_sql;
    PREPARE stmt FROM @sqlv;
    EXECUTE stmt;
    DEALLOCATE PREPARE stmt;
 
end$$

CREATE DEFINER=`gbfyzzmy_m_p_adm`@`%` PROCEDURE `sp_detele_answers_for_question` (IN `answer_id` INT)  begin
	DECLARE in_sql MEDIUMTEXT;
    SET @answer_id = answer_id;

	SET in_sql = "DELETE FROM gbfyzzmy_medic_panels.question_answers WHERE id = @answer_id;";
	SET @sqlv = in_sql;
    PREPARE stmt FROM @sqlv;
    EXECUTE stmt;
    DEALLOCATE PREPARE stmt;

end$$

CREATE DEFINER=`gbfyzzmy_m_p_adm`@`%` PROCEDURE `sp_excel_get_answer_report` (IN `panel_id` INT, IN `patient_id` INT)  begin
	DECLARE in_sql MEDIUMTEXT;
    
	SET @panel_id = panel_id;
    SET @patient_id = patient_id;
    
    SET in_sql = "SELECT A.pharmacy_id as 'pharmacy_code', A.id_pharmacist as 'pharmacist_code',
B.oib, D.panel_name,A.id_question, C.question_text, A.answer_text, A.date_submitted 
FROM gbfyzzmy_medic_panels.patient_answers AS A
INNER JOIN gbfyzzmy_medic_panels.patient AS B
ON A.id_patient = B.id
INNER JOIN gbfyzzmy_medic_panels.questions AS C
ON A.id_question = C.id
INNER JOIN gbfyzzmy_medic_panels.surv_survey_panels AS D
ON A.id_panel = D.id
WHERE id_patient = @patient_id AND id_panel = @panel_id;
";

    SET @sqlv = in_sql;
    PREPARE stmt FROM @sqlv;
    EXECUTE stmt;
    DEALLOCATE PREPARE stmt;

end$$

CREATE DEFINER=`gbfyzzmy_m_p_adm`@`%` PROCEDURE `sp_excel_get_questions_per_panel` (IN `panel_id` INT)  begin
	DECLARE in_sql MEDIUMTEXT;
    
	SET @panel_id = panel_id;
    
    SET in_sql = "SELECT A.id, A.question_text FROM gbfyzzmy_medic_panels.questions AS A
INNER JOIN gbfyzzmy_medic_panels.surv_panel_questions AS B
ON A.id = B.questions_id
WHERE surv_survey_panels_id = @panel_id;";

    SET @sqlv = in_sql;
    PREPARE stmt FROM @sqlv;
    EXECUTE stmt;
    DEALLOCATE PREPARE stmt;

end$$

CREATE DEFINER=`gbfyzzmy_m_p_adm`@`%` PROCEDURE `sp_excel_get_users_per_panel` (IN `panel_id` INT)  begin
	DECLARE in_sql MEDIUMTEXT;
    
	SET @panel_id = panel_id;
    
    SET in_sql = "SELECT DISTINCT id_patient FROM gbfyzzmy_medic_panels.patient_answers WHERE id_panel = @panel_id;";

    SET @sqlv = in_sql;
    PREPARE stmt FROM @sqlv;
    EXECUTE stmt;
    DEALLOCATE PREPARE stmt;

end$$

CREATE DEFINER=`gbfyzzmy_m_p_adm`@`%` PROCEDURE `sp_get_answers_for_questions` (IN `panel_id` INT)  begin
	DECLARE in_sql MEDIUMTEXT;
    
	SET @panel_id = panel_id;
    
    SET in_sql = "
SELECT A.id as 'answer_id', A.questions_id as 'question_id', A.text as 'answer' FROM gbfyzzmy_medic_panels.question_answers AS A
INNER JOIN gbfyzzmy_medic_panels.questions AS B
ON A.questions_id = B.id
INNER JOIN gbfyzzmy_medic_panels.surv_panel_questions AS C
ON B.id = C.questions_id
WHERE C.surv_survey_panels_id = @panel_id;";

    SET @sqlv = in_sql;
    PREPARE stmt FROM @sqlv;
    EXECUTE stmt;
    DEALLOCATE PREPARE stmt;

end$$

CREATE DEFINER=`gbfyzzmy_m_p_adm`@`%` PROCEDURE `sp_get_patient_info_for_new_record` (IN `id` INT, IN `id_pharmacist` INT)  begin
	DECLARE in_sql MEDIUMTEXT;
    
	SET @id_patient = id;
    SET @id_pharmacist = id_pharmacist;
    
    SET in_sql = "SELECT NOW()  INTO @date_submitted;";
    SET @sqlv = in_sql;
    PREPARE stmt FROM @sqlv;
    EXECUTE stmt;
    DEALLOCATE PREPARE stmt;
    
    
    SET in_sql =  "INSERT INTO gbfyzzmy_medic_panels.patient_record_history(date_submitted, patient_id, pharmacist_id) 
   VALUES(@date_submitted,@id_patient, @id_pharmacist);";
   SET @sqlv = in_sql;
    PREPARE stmt FROM @sqlv;
    EXECUTE stmt;
    DEALLOCATE PREPARE stmt;
    
    
    SET in_sql = "SELECT LAST_INSERT_ID()  INTO @id_patient_record_history;";
    SET @sqlv = in_sql;
    PREPARE stmt FROM @sqlv;
    EXECUTE stmt;
    DEALLOCATE PREPARE stmt;
    
    
    SET in_sql = "SELECT A.id AS 'patient_record_history_id', A.date_submitted AS 'submission_date', B.id AS 'patient_id', B.firstName AS 'patient_firstName', B.lastName AS 'patient_lastName',
A.pharmacist_id, C.name as 'pharmacist_name' FROM gbfyzzmy_medic_panels.patient_record_history AS A 
INNER JOIN gbfyzzmy_medic_panels.patient AS B ON A.patient_id = B.id
INNER JOIN gbfyzzmy_medic_panels.pharmacist AS C ON A.pharmacist_id = C.id WHERE B.id = @id_patient AND A.id = @id_patient_record_history;";

    SET @sqlv = in_sql;
    PREPARE stmt FROM @sqlv;
    EXECUTE stmt;
    DEALLOCATE PREPARE stmt;

end$$

CREATE DEFINER=`gbfyzzmy_m_p_adm`@`%` PROCEDURE `sp_get_patient_records_by_id` (IN `id` INT)  begin
	DECLARE in_sql MEDIUMTEXT;
    
	SET @id = id;
    
    SET in_sql = "SELECT A.id AS 'patient_record_history_id', A.date_submitted AS 'submission_date', B.id AS 'patient_id', B.firstName AS 'patient_firstName',
B.lastName AS 'patient_lastName', B.oib, B.mbo, B.age, B.gender, B.email, B.phoneNumber, B.city, B.address, B.zip,
A.pharmacist_id, C.name as 'pharmacist_name' FROM gbfyzzmy_medic_panels.patient_record_history AS A 
INNER JOIN gbfyzzmy_medic_panels.patient AS B ON A.patient_id = B.id
INNER JOIN gbfyzzmy_medic_panels.pharmacist AS C ON A.pharmacist_id = C.id WHERE B.id = @id;";

    SET @sqlv = in_sql;
    PREPARE stmt FROM @sqlv;
    EXECUTE stmt;
    DEALLOCATE PREPARE stmt;

end$$

CREATE DEFINER=`gbfyzzmy_m_p_adm`@`%` PROCEDURE `sp_get_questions` (IN `panel_id` INT)  begin
	DECLARE in_sql MEDIUMTEXT;
    
	SET @panel_id = panel_id;
    
    SET in_sql = "
SELECT A.id as 'question_id', A.question_text, A.question_details, A.question_category_id,C.surv_panel_labels_questions_id AS 'label_id', C.question_order 
FROM gbfyzzmy_medic_panels.questions AS A 
INNER JOIN gbfyzzmy_medic_panels.surv_panel_questions AS C
ON A.id = C.questions_id
WHERE C.surv_survey_panels_id = @panel_id;";

    SET @sqlv = in_sql;
    PREPARE stmt FROM @sqlv;
    EXECUTE stmt;
    DEALLOCATE PREPARE stmt;

end$$

CREATE DEFINER=`gbfyzzmy_m_p_adm`@`%` PROCEDURE `sp_get_questions_basedLabel` (IN `label_id` INT)  begin
	DECLARE in_sql MEDIUMTEXT;
    SET @label_id = label_id;

	SET in_sql = "SELECT questions.id, questions.question_text, questions.question_category_id ,surv_panel_questions.surv_panel_labels_questions_id 
        FROM surv_panel_questions 
        INNER JOIN surv_panel_labels_questions ON surv_panel_questions.surv_panel_labels_questions_id = surv_panel_labels_questions.id
        INNER JOIN questions ON questions.id = surv_panel_questions.questions_id
        WHERE surv_panel_questions.surv_panel_labels_questions_id = @label_id;";
	SET @sqlv = in_sql;
    PREPARE stmt FROM @sqlv;
    EXECUTE stmt;
    DEALLOCATE PREPARE stmt;

end$$

CREATE DEFINER=`gbfyzzmy_m_p_adm`@`%` PROCEDURE `sp_get_questions_basedLabel_andPanel` (IN `panel_id` INT, IN `label_id` INT)  begin
	DECLARE in_sql MEDIUMTEXT;
    SET @label_id = label_id;
	SET @panel_id = panel_id;

	SET in_sql = "SELECT DISTINCT A.id, A.question_text FROM gbfyzzmy_medic_panels.questions AS A 
INNER JOIN gbfyzzmy_medic_panels.surv_panel_questions AS B ON A.id = B.questions_id
INNER JOIN gbfyzzmy_medic_panels.surv_panel_labels_questions AS C on  C.id = B.surv_panel_labels_questions_id
INNER JOIN gbfyzzmy_medic_panels.surv_survey_panels AS D ON D.id = C.surv_survey_panels_id
WHERE D.id = @panel_id AND  C.id = @label_id;";
	SET @sqlv = in_sql;
    PREPARE stmt FROM @sqlv;
    EXECUTE stmt;
    DEALLOCATE PREPARE stmt;

end$$

CREATE DEFINER=`gbfyzzmy_m_p_adm`@`%` PROCEDURE `sp_get_user_by_id` (IN `id` INT)  begin
	DECLARE in_sql MEDIUMTEXT;
    
	SET @id = id;
    
    SET in_sql = "SELECT B.id, A.name, B.username, B.password, B.email, B.user_id FROM gbfyzzmy_medic_panels.pharmacist AS A INNER JOIN gbfyzzmy_medic_panels.user_credentials AS B
ON A.id = B.user_id WHERE B.id = @id;";

    SET @sqlv = in_sql;
    PREPARE stmt FROM @sqlv;
    EXECUTE stmt;
    DEALLOCATE PREPARE stmt;

end$$

CREATE DEFINER=`gbfyzzmy_m_p_adm`@`%` PROCEDURE `sp_get_user_by_un_pw` (IN `username` VARCHAR(255), IN `password` MEDIUMTEXT)  begin
	DECLARE in_sql MEDIUMTEXT;
    
	SET @username = username;
   	SET @password = password;
    
    SET in_sql = "SELECT B.id, A.name, B.username, B.password, B.email, B.user_id FROM gbfyzzmy_medic_panels.pharmacist AS A INNER JOIN gbfyzzmy_medic_panels.user_credentials AS B
ON A.id = B.user_id WHERE B.username = @username AND B.password = @password;";
    SET @sqlv = in_sql;
    PREPARE stmt FROM @sqlv;
    EXECUTE stmt;
    DEALLOCATE PREPARE stmt;

end$$

CREATE DEFINER=`gbfyzzmy_m_p_adm`@`%` PROCEDURE `sp_insert_answers` (IN `id_patient_record_history` INT, IN `id_patient` INT, IN `id_pharmacist` INT, IN `id_panel` INT, IN `id_question` INT, IN `id_answer` INT, IN `answer_text` VARCHAR(255))  begin
	DECLARE in_sql MEDIUMTEXT;
    
	SET in_sql = "SELECT NOW()  INTO @date_submitted;";
    SET @sqlv = in_sql;
    PREPARE stmt FROM @sqlv;
    EXECUTE stmt;
    DEALLOCATE PREPARE stmt;


	SET @id_patient = id_patient;
	SET @id_pharmacist = id_pharmacist;
    SET @id_panel = id_panel;
    SET @id_question = id_question;
	SET @id_answer = id_answer;
   	SET @answer_text = answer_text;
    SET @id_patient_record_history = id_patient_record_history;
    
	SET in_sql = "SELECT A.id FROM gbfyzzmy_medic_panels.pharmacy AS A 
    INNER JOIN gbfyzzmy_medic_panels.pharmacist AS B 
    ON A.id = B.pharmacy_id
	WHERE B.id = @id_pharmacist INTO @pharmacy_id;";
    SET @sqlv = in_sql;
    PREPARE stmt FROM @sqlv;
    EXECUTE stmt;
    DEALLOCATE PREPARE stmt;
    
    
    SET in_sql = "INSERT INTO gbfyzzmy_medic_panels.patient_answers(id_patient_record_history, id_patient, id_pharmacist, id_survey, id_panel, id_question, id_answer, date_submitted, answer_text, pharmacy_id) 
    VALUES(@id_patient_record_history, @id_patient, @id_pharmacist, 1, @id_panel, @id_question, @id_answer, @date_submitted, @answer_text,@pharmacy_id);";
    SET @sqlv = in_sql;
    PREPARE stmt FROM @sqlv;
    EXECUTE stmt;
    DEALLOCATE PREPARE stmt;
end$$

CREATE DEFINER=`gbfyzzmy_m_p_adm`@`%` PROCEDURE `sp_insert_label_for_panels` (IN `label_title` VARCHAR(255), IN `surv_survey_panels_id` INT)  begin
	DECLARE in_sql MEDIUMTEXT;
    
    SET @label_title = label_title;
    SET @surv_survey_panels_id = surv_survey_panels_id;
    
    SET in_sql = "INSERT INTO gbfyzzmy_medic_panels.surv_panel_labels_questions
    (label_title, start_order, end_order, surv_survey_panels_id) VALUES(@label_title,1,1,@surv_survey_panels_id)";
	SET @sqlv = in_sql;
    PREPARE stmt FROM @sqlv;
    EXECUTE stmt;
    DEALLOCATE PREPARE stmt;

end$$

CREATE DEFINER=`gbfyzzmy_m_p_adm`@`%` PROCEDURE `sp_insert_question` (IN `question_category_id` INT, IN `question_name` VARCHAR(255), IN `surv_panel_labels_questions_id` INT)  begin
	DECLARE in_sql MEDIUMTEXT;
    
    SET @surv_panel_labels_questions_id = surv_panel_labels_questions_id;

   SET in_sql = "INSERT INTO gbfyzzmy_medic_panels.questions(question_text, question_details, surv_survey_language_id, question_category_id)
   VALUES('@P1', 'novi', 1, @P3)";
	SET in_sql = REPLACE(in_sql, '@P1', question_name);
    SET in_sql = REPLACE(in_sql, '@P3', question_category_id);
	SET @sqlv = in_sql;
    PREPARE stmt FROM @sqlv;
    EXECUTE stmt;
    DEALLOCATE PREPARE stmt;

	SET in_sql = "SELECT LAST_INSERT_ID()  INTO @question_id;";
    SET @sqlv = in_sql;
    PREPARE stmt FROM @sqlv;
    EXECUTE stmt;
    DEALLOCATE PREPARE stmt;
    
    
    SET in_sql = "SELECT surv_survey_panels_id FROM gbfyzzmy_medic_panels.surv_panel_labels_questions WHERE id = @surv_panel_labels_questions_id  INTO @panel_id;";
    SET @sqlv = in_sql;
    PREPARE stmt FROM @sqlv;
    EXECUTE stmt;
    DEALLOCATE PREPARE stmt;
    
    
    SET in_sql = "INSERT INTO gbfyzzmy_medic_panels.surv_panel_questions(question_order, surv_survey_panels_id, questions_id,surv_panel_labels_questions_id)
   VALUES(1,@panel_id, @question_id, @surv_panel_labels_questions_id)";
	SET @sqlv = in_sql;
    PREPARE stmt FROM @sqlv;
    EXECUTE stmt;
    DEALLOCATE PREPARE stmt;
    
        
    	SET in_sql = "SELECT @question_id as 'last_inserted_question_id';";
    SET @sqlv = in_sql;
    PREPARE stmt FROM @sqlv;
    EXECUTE stmt;
    DEALLOCATE PREPARE stmt;
end$$

CREATE DEFINER=`gbfyzzmy_m_p_adm`@`%` PROCEDURE `sp_update_answer_for_questions` (IN `new_answer_txt` VARCHAR(255), IN `answer_id` INT)  begin
	DECLARE in_sql MEDIUMTEXT;
    SET @new_answer_txt = new_answer_txt;
    SET @answer_id = answer_id;

	SET in_sql = "UPDATE gbfyzzmy_medic_panels.question_answers SET text = @new_answer_txt WHERE id = @answer_id;";
	SET @sqlv = in_sql;
    PREPARE stmt FROM @sqlv;
    EXECUTE stmt;
    DEALLOCATE PREPARE stmt;

end$$

CREATE DEFINER=`gbfyzzmy_m_p_adm`@`%` PROCEDURE `sp_update_label_name` (IN `label_id` INT, IN `label_name` VARCHAR(255))  begin
	DECLARE in_sql MEDIUMTEXT;
    
	SET @label_id = label_id;
    SET @label_name = label_name;
    
    SET in_sql = "UPDATE gbfyzzmy_medic_panels.surv_panel_labels_questions 
    SET label_title = @label_name WHERE id = @label_id;";
	SET @sqlv = in_sql;
    PREPARE stmt FROM @sqlv;
    EXECUTE stmt;
    DEALLOCATE PREPARE stmt;

end$$

CREATE DEFINER=`gbfyzzmy_m_p_adm`@`%` PROCEDURE `sp_update_panel_name_by_id` (IN `panel_id` INT, IN `panel_name` VARCHAR(255))  begin
	DECLARE in_sql MEDIUMTEXT;
    
	SET @panel_id = panel_id;
    SET @panel_name = panel_name;
    
	SET in_sql =  "UPDATE gbfyzzmy_medic_panels.surv_survey_panels SET panel_name = @panel_name WHERE id = @panel_id;";
	SET @sqlv = in_sql;
    PREPARE stmt FROM @sqlv;
    EXECUTE stmt;
    DEALLOCATE PREPARE stmt;
 
end$$

CREATE DEFINER=`gbfyzzmy_m_p_adm`@`%` PROCEDURE `sp_update_question_name` (IN `question_name` VARCHAR(255), IN `question_id` INT)  begin
	DECLARE in_sql MEDIUMTEXT;
    
    SET @question_name = question_name;
    SET @question_id = question_id;
    
    SET in_sql = "UPDATE gbfyzzmy_medic_panels.questions SET question_text = @question_name WHERE id = @question_id;";
	SET @sqlv = in_sql;
    PREPARE stmt FROM @sqlv;
    EXECUTE stmt;
    DEALLOCATE PREPARE stmt;

end$$

CREATE DEFINER=`gbfyzzmy_m_p_adm`@`%` PROCEDURE `sp_view_record_by_id` (IN `id` INT)  begin
	DECLARE in_sql MEDIUMTEXT;
    
	SET @record_id = id;
    
    SET in_sql = "SELECT B.panel_name, C.question_text, A.date_submitted, A.answer_text FROM gbfyzzmy_medic_panels.patient_answers AS A 
INNER JOIN gbfyzzmy_medic_panels.surv_survey_panels AS B
ON A.id_panel = B.id
INNER JOIN gbfyzzmy_medic_panels.questions AS C
ON A.id_question = C.id
WHERE A.id_patient_record_history = @record_id;";

    SET @sqlv = in_sql;
    PREPARE stmt FROM @sqlv;
    EXECUTE stmt;
    DEALLOCATE PREPARE stmt;

end$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `patient`
--

CREATE TABLE `patient` (
  `id` int(11) NOT NULL,
  `firstName` varchar(255) NOT NULL,
  `lastName` varchar(255) DEFAULT NULL,
  `oib` varchar(11) NOT NULL,
  `mbo` varchar(9) DEFAULT NULL,
  `age` int(11) NOT NULL,
  `gender` varchar(255) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `phoneNumber` int(11) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `zip` int(11) DEFAULT NULL,
  `date_patient_created` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `patient`
--

INSERT INTO `patient` (`id`, `firstName`, `lastName`, `oib`, `mbo`, `age`, `gender`, `email`, `phoneNumber`, `city`, `address`, `zip`, `date_patient_created`) VALUES
(1, 'Josip', 'Vlah', '12345678911', '123456789', 1, 'Male', NULL, NULL, NULL, NULL, NULL, '2020-04-13 00:00:00'),
(2, 'Ivor', 'Baric', '12345678911', '123456789', 2, 'Male', NULL, NULL, NULL, NULL, NULL, '2020-04-13 00:00:00'),
(3, 'Marko', 'Milardic', '12345678911', '123456789', 3, 'Male', NULL, NULL, NULL, NULL, NULL, '2020-04-14 09:07:19'),
(4, 'Gimi', 'Elezi', '12345678911', '123456789', 4, 'Male', NULL, NULL, NULL, NULL, NULL, '2020-04-14 09:19:47'),
(5, 'Arben', 'Hoxha', '12345678911', '123456789', 5, 'Male', NULL, NULL, NULL, NULL, NULL, '2020-04-14 09:20:21'),
(6, 'Beni', 'Cengu', '12345678911', '123456789', 6, 'Male', NULL, NULL, NULL, NULL, NULL, '2020-04-14 09:21:14'),
(7, 'Josip', 'Pandza', '12345678911', '123456789', 7, 'Male', NULL, NULL, NULL, NULL, NULL, '2020-04-14 09:34:28'),
(8, 'John', 'Doe', '12345678911', '123456789', 8, 'Male', NULL, NULL, NULL, NULL, NULL, '2020-04-14 10:28:02'),
(9, 'Final', 'Test', '12345678911', '123456789', 9, 'Male', NULL, NULL, NULL, NULL, NULL, '2020-04-14 11:34:04'),
(12, 'Edi', 'Rama', '25971456981', '254569879', 21, 'Male', 'edirama@gmail.com', 955556529, 'Zagreb', 'Slavka Kolara 23', 10410, '2020-04-20 12:20:39'),
(13, 'Ivan', 'Ivankovic', '12345678901', '123456789', 25, 'Male', 'ivan.ivankovic@gmail.com', 955353535, 'Zagreb', 'Damira Tomljanovica 15', 10000, '2020-04-21 05:37:28'),
(14, 'Zvonimir ', 'Pandza', '12312312312', '123123123', 22, 'Male', 'zvone.pandzaa@gmail.com', 955233678, 'Zagreb', 'Trakoscanska 41', 10000, '2020-04-23 11:45:03');

-- --------------------------------------------------------

--
-- Table structure for table `patient_answers`
--

CREATE TABLE `patient_answers` (
  `id` int(11) NOT NULL,
  `id_patient_record_history` int(11) DEFAULT NULL,
  `id_patient` int(11) DEFAULT NULL,
  `id_pharmacist` int(11) DEFAULT NULL,
  `id_survey` int(11) DEFAULT NULL,
  `id_panel` int(11) DEFAULT NULL,
  `id_question` int(11) DEFAULT NULL,
  `id_answer` int(11) DEFAULT NULL,
  `date_submitted` datetime DEFAULT NULL,
  `answer_text` varchar(255) DEFAULT NULL,
  `option_value` int(11) DEFAULT NULL,
  `pharmacy_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `patient_answers`
--

INSERT INTO `patient_answers` (`id`, `id_patient_record_history`, `id_patient`, `id_pharmacist`, `id_survey`, `id_panel`, `id_question`, `id_answer`, `date_submitted`, `answer_text`, `option_value`, `pharmacy_id`) VALUES
(1, 2, 1, 4, 1, 1, 1, -1, '2020-04-14 07:54:08', 'N/A', NULL, 1),
(2, 3, 1, 4, 1, 1, 1, -1, '2020-04-14 07:55:32', 'N/A', NULL, 1),
(3, 4, 1, 4, 1, 1, 1, -1, '2020-04-14 07:57:47', 'N/A', NULL, 1),
(4, 5, 1, 4, 1, 1, 1, -1, '2020-04-14 08:02:43', 'N/A', NULL, 1),
(5, 6, 1, 4, 1, 1, 1, -1, '2020-04-14 08:04:58', 'N/A', NULL, 1),
(6, 7, 1, 4, 1, 1, 2, -1, '2020-04-14 08:06:20', 'N/A', NULL, 1),
(7, 8, 1, 4, 1, 1, 1, -1, '2020-04-14 08:07:42', '31', NULL, 1),
(8, 9, 1, 4, 1, 1, 1, -1, '2020-04-14 08:08:15', 'N/A', NULL, 1),
(9, 10, 1, 4, 1, 1, 1, -1, '2020-04-14 08:08:19', 'N/A', NULL, 1),
(10, 11, 1, 4, 1, 1, 1, -1, '2020-04-14 08:08:23', 'N/A', NULL, 1),
(11, 22, 1, 4, 1, 1, 1, -1, '2020-04-14 08:28:55', '312', NULL, 1),
(12, 22, 1, 4, 1, 1, 1, -1, '2020-04-14 08:29:12', '312', NULL, 1),
(13, 24, 1, 4, 1, 1, 1, -1, '2020-04-14 08:30:14', '23231321', NULL, 1),
(14, 25, 1, 4, 1, 1, 1, -1, '2020-04-14 08:30:59', '4', NULL, 1),
(15, 25, 1, 4, 1, 1, 2, -1, '2020-04-14 08:30:59', '123', NULL, 1),
(16, 25, 1, 4, 1, 1, 4, -1, '2020-04-14 08:30:59', 'on', NULL, 1),
(17, 30, 1, 4, 1, 1, 1, -1, '2020-04-14 08:33:29', '21321', NULL, 1),
(18, 30, 1, 4, 1, 1, 2, -1, '2020-04-14 08:33:30', '213', NULL, 1),
(19, 30, 1, 4, 1, 1, 4, -1, '2020-04-14 08:33:30', 'on', NULL, 1),
(20, 30, 1, 4, 1, 1, 9, 9, '2020-04-14 08:33:30', 'Pusac', NULL, 1),
(21, 30, 1, 4, 1, 1, 10, 12, '2020-04-14 08:33:31', 'Cigarete', NULL, 1),
(22, 31, 1, 4, 1, 1, 1, -1, '2020-04-14 08:34:31', '213', NULL, 1),
(23, 32, 1, 4, 1, 1, 1, -1, '2020-04-14 08:35:18', '213213', NULL, 1),
(24, 32, 1, 4, 1, 1, 2, -1, '2020-04-14 08:35:19', '213312', NULL, 1),
(25, 32, 1, 4, 1, 1, 4, -1, '2020-04-14 08:35:19', 'on', NULL, 1),
(26, 32, 1, 4, 1, 1, 5, -1, '2020-04-14 08:35:20', '31123', NULL, 1),
(27, 32, 1, 4, 1, 1, 8, -1, '2020-04-14 08:35:20', 'on', NULL, 1),
(28, 32, 1, 4, 1, 1, 9, 9, '2020-04-14 08:35:20', 'Pusac', NULL, 1),
(29, 32, 1, 4, 1, 1, 10, 12, '2020-04-14 08:35:21', 'Cigarete', NULL, 1),
(30, 32, 1, 4, 1, 1, 16, 15, '2020-04-14 08:35:21', 'Da', NULL, 1),
(31, 35, 1, 4, 1, 1, 1, -1, '2020-04-14 08:38:13', '3211', NULL, 1),
(32, 35, 1, 4, 1, 1, 2, -1, '2020-04-14 08:38:13', '313', NULL, 1),
(33, 35, 1, 4, 1, 1, 4, -1, '2020-04-14 08:38:14', 'on', NULL, 1),
(34, 35, 1, 4, 1, 1, 5, -1, '2020-04-14 08:38:14', '123', NULL, 1),
(35, 35, 1, 4, 1, 1, 6, -1, '2020-04-14 08:38:15', '3', NULL, 1),
(36, 35, 1, 4, 1, 1, 9, 9, '2020-04-14 08:38:15', 'Pusac', NULL, 1),
(37, 35, 1, 4, 1, 1, 10, 12, '2020-04-14 08:38:16', 'Cigarete', NULL, 1),
(38, 35, 1, 4, 1, 1, 23, 23, '2020-04-14 08:38:16', 'Ne', NULL, 1),
(39, 35, 1, 4, 1, 1, 24, -1, '2020-04-14 08:38:16', '31', NULL, 1),
(40, 35, 1, 4, 1, 1, 25, -1, '2020-04-14 08:38:17', 'on', NULL, 1),
(41, 35, 1, 4, 1, 1, 26, 25, '2020-04-14 08:38:17', 'Mali (1275-1700)', NULL, 1),
(42, 37, 1, 4, 1, 1, 1, -1, '2020-04-14 08:41:29', '213', NULL, 1),
(43, 37, 1, 4, 1, 1, 2, -1, '2020-04-14 08:41:29', '321', NULL, 1),
(44, 37, 1, 4, 1, 1, 4, -1, '2020-04-14 08:41:29', 'on', NULL, 1),
(45, 37, 1, 4, 1, 1, 5, -1, '2020-04-14 08:41:30', '213', NULL, 1),
(46, 37, 1, 4, 1, 1, 6, -1, '2020-04-14 08:41:30', '3', NULL, 1),
(47, 37, 1, 4, 1, 1, 8, -1, '2020-04-14 08:41:31', 'on', NULL, 1),
(48, 37, 1, 4, 1, 1, 9, 9, '2020-04-14 08:41:31', 'Pusac', NULL, 1),
(49, 37, 1, 4, 1, 1, 10, 12, '2020-04-14 08:41:31', 'Cigarete', NULL, 1),
(50, 37, 1, 4, 1, 1, 14, -1, '2020-04-14 08:41:32', 'on', NULL, 1),
(51, 37, 1, 4, 1, 1, 15, -1, '2020-04-14 08:41:32', 'on', NULL, 1),
(52, 37, 1, 4, 1, 1, 17, -1, '2020-04-14 08:41:33', 'on', NULL, 1),
(53, 37, 1, 4, 1, 1, 18, -1, '2020-04-14 08:41:33', 'on', NULL, 1),
(54, 37, 1, 4, 1, 1, 22, 21, '2020-04-14 08:41:33', 'Nije odabrano', NULL, 1),
(55, 37, 1, 4, 1, 1, 23, 22, '2020-04-14 08:41:34', 'Da', NULL, 1),
(56, 37, 1, 4, 1, 1, 24, -1, '2020-04-14 08:41:34', '2133as', NULL, 1),
(57, 37, 1, 4, 1, 1, 25, -1, '2020-04-14 08:41:35', 'on', NULL, 1),
(58, 37, 1, 4, 1, 1, 26, 25, '2020-04-14 08:41:35', 'Mali (1275-1700)', NULL, 1),
(59, 38, 1, 4, 1, 1, 1, -1, '2020-04-14 08:42:25', '12321', NULL, 1),
(60, 38, 1, 4, 1, 1, 9, 9, '2020-04-14 08:42:25', 'Pusac', NULL, 1),
(61, 38, 1, 4, 1, 1, 10, 12, '2020-04-14 08:42:26', 'Cigarete', NULL, 1),
(62, 39, 1, 4, 1, 1, 1, -1, '2020-04-14 08:43:24', '312231', NULL, 1),
(63, 39, 1, 4, 1, 1, 2, -1, '2020-04-14 08:43:25', '3123', NULL, 1),
(64, 39, 1, 4, 1, 1, 4, -1, '2020-04-14 08:43:25', 'on', NULL, 1),
(65, 39, 1, 4, 1, 1, 5, -1, '2020-04-14 08:43:25', '123', NULL, 1),
(66, 39, 1, 4, 1, 1, 9, 9, '2020-04-14 08:43:26', 'Pusac', NULL, 1),
(67, 39, 1, 4, 1, 1, 10, 12, '2020-04-14 08:43:26', 'Cigarete', NULL, 1),
(68, 40, 1, 4, 1, 1, 1, -1, '2020-04-14 08:43:51', '123', NULL, 1),
(69, 40, 1, 4, 1, 1, 2, -1, '2020-04-14 08:43:52', '132', NULL, 1),
(70, 40, 1, 4, 1, 1, 9, 9, '2020-04-14 08:43:52', 'Pusac', NULL, 1),
(71, 40, 1, 4, 1, 1, 10, 12, '2020-04-14 08:43:53', 'Cigarete', NULL, 1),
(72, 43, 1, 4, 1, 1, 2, -1, '2020-04-14 08:45:28', '321', NULL, 1),
(73, 43, 1, 4, 1, 1, 5, -1, '2020-04-14 08:45:28', '12', NULL, 1),
(74, 43, 1, 4, 1, 1, 6, -1, '2020-04-14 08:45:29', '231', NULL, 1),
(75, 43, 1, 4, 1, 1, 9, 9, '2020-04-14 08:45:29', 'Pusac', NULL, 1),
(76, 43, 1, 4, 1, 1, 10, 12, '2020-04-14 08:45:29', 'Cigarete', NULL, 1),
(77, 49, 5, 4, 1, 1, 1, -1, '2020-04-14 09:49:03', '213', NULL, 1),
(78, 49, 5, 4, 1, 1, 2, -1, '2020-04-14 09:49:04', '132312', NULL, 1),
(79, 49, 5, 4, 1, 1, 4, -1, '2020-04-14 09:49:04', 'on', NULL, 1),
(80, 49, 5, 4, 1, 1, 5, -1, '2020-04-14 09:49:04', '23321', NULL, 1),
(81, 49, 5, 4, 1, 1, 9, 9, '2020-04-14 09:49:05', 'Pusac', NULL, 1),
(82, 49, 5, 4, 1, 1, 10, 12, '2020-04-14 09:49:05', 'Cigarete', NULL, 1),
(83, 49, 5, 4, 1, 1, 20, -1, '2020-04-14 09:49:06', '321321wd', NULL, 1),
(84, 49, 5, 4, 1, 1, 21, 17, '2020-04-14 09:49:06', 'Da', NULL, 1),
(85, 51, 8, 4, 1, 1, 1, -1, '2020-04-14 10:36:18', '20', NULL, 1),
(86, 51, 8, 4, 1, 1, 2, -1, '2020-04-14 10:36:18', '30', NULL, 1),
(87, 51, 8, 4, 1, 1, 4, -1, '2020-04-14 10:36:19', 'on', NULL, 1),
(88, 51, 8, 4, 1, 1, 5, -1, '2020-04-14 10:36:19', '23', NULL, 1),
(89, 51, 8, 4, 1, 1, 6, -1, '2020-04-14 10:36:20', '321', NULL, 1),
(90, 51, 8, 4, 1, 1, 8, -1, '2020-04-14 10:36:20', 'on', NULL, 1),
(91, 51, 8, 4, 1, 1, 9, 9, '2020-04-14 10:36:20', 'Pusac', NULL, 1),
(92, 51, 8, 4, 1, 1, 10, 12, '2020-04-14 10:36:21', 'Cigarete', NULL, 1),
(93, 51, 8, 4, 1, 1, 11, -1, '2020-04-14 10:36:21', '13', NULL, 1),
(94, 51, 8, 4, 1, 1, 12, -1, '2020-04-14 10:36:22', '31', NULL, 1),
(95, 51, 8, 4, 1, 1, 13, -1, '2020-04-14 10:36:22', '311', NULL, 1),
(96, 51, 8, 4, 1, 1, 14, -1, '2020-04-14 10:36:22', 'on', NULL, 1),
(97, 51, 8, 4, 1, 1, 15, -1, '2020-04-14 10:36:23', 'on', NULL, 1),
(98, 51, 8, 4, 1, 1, 16, 16, '2020-04-14 10:36:23', 'Ne', NULL, 1),
(99, 51, 8, 4, 1, 1, 17, -1, '2020-04-14 10:36:24', 'on', NULL, 1),
(100, 51, 8, 4, 1, 1, 18, -1, '2020-04-14 10:36:24', 'on', NULL, 1),
(101, 51, 8, 4, 1, 1, 19, -1, '2020-04-14 10:36:24', '313ggg', NULL, 1),
(102, 51, 8, 4, 1, 1, 20, -1, '2020-04-14 10:36:25', '3213ggg', NULL, 1),
(103, 51, 8, 4, 1, 1, 21, 18, '2020-04-14 10:36:25', 'Ne', NULL, 1),
(104, 51, 8, 4, 1, 1, 22, 21, '2020-04-14 10:36:26', 'Nije odabrano', NULL, 1),
(105, 51, 8, 4, 1, 1, 23, 23, '2020-04-14 10:36:26', 'Ne', NULL, 1),
(106, 51, 8, 4, 1, 1, 24, -1, '2020-04-14 10:36:26', 'aktivnost', NULL, 1),
(107, 51, 8, 4, 1, 1, 25, -1, '2020-04-14 10:36:27', 'on', NULL, 1),
(108, 51, 8, 4, 1, 1, 26, 25, '2020-04-14 10:36:27', 'Mali (1275-1700)', NULL, 1),
(109, 52, 3, 4, 1, 6, 183, -1, '2020-04-14 11:22:57', '2018-02-01', NULL, 1),
(110, 52, 3, 4, 1, 6, 184, -1, '2020-04-14 11:22:57', '01:00', NULL, 1),
(111, 52, 3, 4, 1, 6, 185, -1, '2020-04-14 11:22:58', '213312', NULL, 1),
(112, 52, 3, 4, 1, 6, 187, 93, '2020-04-14 11:22:58', 'Sumamed', NULL, 1),
(113, 52, 3, 4, 1, 6, 188, -1, '2020-04-14 11:22:59', 'adsdsa', NULL, 1),
(120, 1, 1, 1, 1, 1, 1, 1, '2020-04-22 06:43:37', 'test', NULL, 1),
(121, 79, 12, 4, 1, 11, 196, -1, '2020-04-22 06:49:31', '2312', NULL, 1),
(122, 79, 12, 4, 1, 11, 197, -1, '2020-04-22 06:49:31', '1123', NULL, 1),
(123, 79, 12, 4, 1, 11, 198, -1, '2020-04-22 06:49:31', '132123', NULL, 1),
(124, 79, 12, 4, 1, 11, 199, -1, '2020-04-22 06:49:32', '321132', NULL, 1),
(125, 79, 12, 4, 1, 11, 200, -1, '2020-04-22 06:49:32', '231', NULL, 1),
(126, 79, 12, 4, 1, 11, 202, 142, '2020-04-22 06:49:33', 'Ne', NULL, 1),
(127, 79, 12, 4, 1, 11, 203, 143, '2020-04-22 06:49:33', 'Da', NULL, 1),
(128, 79, 12, 4, 1, 11, 205, 145, '2020-04-22 06:49:34', 'Da', NULL, 1),
(129, 79, 12, 4, 1, 11, 207, 148, '2020-04-22 06:49:34', 'Negativno', NULL, 1),
(130, 80, 2, 4, 1, 11, 196, -1, '2020-04-22 06:50:08', '123', NULL, 1),
(131, 80, 2, 4, 1, 11, 197, -1, '2020-04-22 06:50:09', '3212', NULL, 1),
(132, 80, 2, 4, 1, 11, 198, -1, '2020-04-22 06:50:09', '12', NULL, 1),
(133, 80, 2, 4, 1, 11, 199, -1, '2020-04-22 06:50:09', '22', NULL, 1),
(134, 80, 2, 4, 1, 11, 200, -1, '2020-04-22 06:50:10', '213', NULL, 1),
(135, 80, 2, 4, 1, 11, 202, 142, '2020-04-22 06:50:10', 'Ne', NULL, 1),
(136, 80, 2, 4, 1, 11, 203, 144, '2020-04-22 06:50:10', 'Ne', NULL, 1),
(137, 80, 2, 4, 1, 11, 205, 145, '2020-04-22 06:50:11', 'Da', NULL, 1),
(138, 80, 2, 4, 1, 11, 207, 147, '2020-04-22 06:50:11', 'Pozitivno', NULL, 1),
(139, 81, 6, 4, 1, 11, 196, -1, '2020-04-22 06:51:05', '13', NULL, 1),
(140, 81, 6, 4, 1, 11, 197, -1, '2020-04-22 06:51:06', '3', NULL, 1),
(141, 81, 6, 4, 1, 11, 198, -1, '2020-04-22 06:51:06', '312', NULL, 1),
(142, 81, 6, 4, 1, 11, 199, -1, '2020-04-22 06:51:06', '132', NULL, 1),
(143, 81, 6, 4, 1, 11, 200, -1, '2020-04-22 06:51:07', '311', NULL, 1),
(144, 81, 6, 4, 1, 11, 202, 142, '2020-04-22 06:51:07', 'Ne', NULL, 1),
(145, 81, 6, 4, 1, 11, 203, 143, '2020-04-22 06:51:07', 'Da', NULL, 1),
(146, 81, 6, 4, 1, 11, 205, 145, '2020-04-22 06:51:08', 'Da', NULL, 1),
(147, 81, 6, 4, 1, 11, 207, 147, '2020-04-22 06:51:08', 'Pozitivno', NULL, 1),
(148, 82, 4, 4, 1, 11, 196, -1, '2020-04-22 06:51:34', '3', NULL, 1),
(149, 82, 4, 4, 1, 11, 197, -1, '2020-04-22 06:51:34', '34', NULL, 1),
(150, 82, 4, 4, 1, 11, 198, -1, '2020-04-22 06:51:34', '41', NULL, 1),
(151, 82, 4, 4, 1, 11, 199, -1, '2020-04-22 06:51:35', '455', NULL, 1),
(152, 82, 4, 4, 1, 11, 200, -1, '2020-04-22 06:51:35', '5555', NULL, 1),
(153, 82, 4, 4, 1, 11, 202, 141, '2020-04-22 06:51:36', 'Da', NULL, 1),
(154, 82, 4, 4, 1, 11, 203, 144, '2020-04-22 06:51:36', 'Ne', NULL, 1),
(155, 82, 4, 4, 1, 11, 205, 146, '2020-04-22 06:51:36', 'Ne', NULL, 1),
(156, 82, 4, 4, 1, 11, 207, 148, '2020-04-22 06:51:37', 'Negativno', NULL, 1),
(168, 88, 5, 4, 1, 3, 54, -1, '2020-04-22 09:52:44', '4', NULL, 1),
(169, 88, 5, 4, 1, 3, 56, -1, '2020-04-22 09:52:44', '12', NULL, 1),
(170, 88, 5, 4, 1, 3, 118, -1, '2020-04-22 09:52:44', '321', NULL, 1),
(171, 88, 5, 4, 1, 3, 120, -1, '2020-04-22 09:52:45', '33', NULL, 1),
(172, 88, 5, 4, 1, 3, 123, -1, '2020-04-22 09:52:45', 'on', NULL, 1),
(173, 88, 5, 4, 1, 3, 125, -1, '2020-04-22 09:52:45', 'on', NULL, 1),
(174, 88, 5, 4, 1, 3, 127, 60, '2020-04-22 09:52:46', 'Da', NULL, 1),
(175, 88, 5, 4, 1, 3, 129, -1, '2020-04-22 09:52:46', '312', NULL, 1),
(176, 88, 5, 4, 1, 3, 131, -1, '2020-04-22 09:52:47', '13', NULL, 1),
(177, 88, 5, 4, 1, 3, 133, -1, '2020-04-22 09:52:47', '44', NULL, 1),
(178, 88, 5, 4, 1, 3, 136, -1, '2020-04-22 09:52:47', '132', NULL, 1),
(179, 88, 5, 4, 1, 3, 138, -1, '2020-04-22 09:52:48', 'on', NULL, 1),
(180, 88, 5, 4, 1, 3, 140, -1, '2020-04-22 09:52:48', 'on', NULL, 1),
(181, 88, 5, 4, 1, 3, 141, -1, '2020-04-22 09:52:49', '31', NULL, 1),
(182, 88, 5, 4, 1, 3, 143, -1, '2020-04-22 09:52:49', '231', NULL, 1),
(183, 88, 5, 4, 1, 3, 145, -1, '2020-04-22 09:52:49', '31', NULL, 1),
(184, 88, 5, 4, 1, 3, 147, -1, '2020-04-22 09:52:50', '23', NULL, 1),
(185, 88, 5, 4, 1, 3, 150, -1, '2020-04-22 09:52:50', '33', NULL, 1),
(186, 88, 5, 4, 1, 3, 151, -1, '2020-04-22 09:52:50', '44', NULL, 1),
(187, 88, 5, 4, 1, 3, 158, -1, '2020-04-22 09:52:51', 'on', NULL, 1),
(188, 88, 5, 4, 1, 3, 159, 62, '2020-04-22 09:52:51', 'Pusac', NULL, 1),
(189, 88, 5, 4, 1, 3, 160, 66, '2020-04-22 09:52:52', 'Lula', NULL, 1),
(190, 88, 5, 4, 1, 3, 162, -1, '2020-04-22 09:52:52', '13', NULL, 1),
(191, 88, 5, 4, 1, 3, 164, -1, '2020-04-22 09:52:52', '1', NULL, 1),
(192, 88, 5, 4, 1, 3, 165, -1, '2020-04-22 09:52:53', '31', NULL, 1),
(193, 88, 5, 4, 1, 3, 167, -1, '2020-04-22 09:52:53', 'on', NULL, 1),
(194, 88, 5, 4, 1, 3, 169, -1, '2020-04-22 09:52:53', 'on', NULL, 1),
(195, 88, 5, 4, 1, 3, 171, 68, '2020-04-22 09:52:54', 'Zadovoljavajuca', NULL, 1),
(196, 88, 5, 4, 1, 3, 173, -1, '2020-04-22 09:52:54', 'on', NULL, 1),
(197, 88, 5, 4, 1, 3, 174, 70, '2020-04-22 09:52:55', 'Da', NULL, 1),
(198, 88, 5, 4, 1, 3, 176, 74, '2020-04-22 09:52:55', 'Da', NULL, 1),
(199, 88, 5, 4, 1, 3, 178, 77, '2020-04-22 09:52:55', 'Ne', NULL, 1),
(200, 88, 5, 4, 1, 3, 180, -1, '2020-04-22 09:52:56', '123', NULL, 1),
(201, 88, 5, 4, 1, 3, 182, -1, '2020-04-22 09:52:56', '41', NULL, 1),
(202, 89, 13, 4, 1, 3, 54, -1, '2020-04-22 09:54:22', '44', NULL, 1),
(203, 89, 13, 4, 1, 3, 56, -1, '2020-04-22 09:54:22', '14', NULL, 1),
(204, 89, 13, 4, 1, 3, 118, -1, '2020-04-22 09:54:23', '14', NULL, 1),
(205, 89, 13, 4, 1, 3, 120, -1, '2020-04-22 09:54:23', '142', NULL, 1),
(206, 89, 13, 4, 1, 3, 123, -1, '2020-04-22 09:54:23', 'on', NULL, 1),
(207, 89, 13, 4, 1, 3, 125, -1, '2020-04-22 09:54:24', 'on', NULL, 1),
(208, 89, 13, 4, 1, 3, 127, 60, '2020-04-22 09:54:24', 'Da', NULL, 1),
(209, 89, 13, 4, 1, 3, 129, -1, '2020-04-22 09:54:25', '41', NULL, 1),
(210, 89, 13, 4, 1, 3, 131, -1, '2020-04-22 09:54:25', '321', NULL, 1),
(211, 89, 13, 4, 1, 3, 133, -1, '2020-04-22 09:54:25', '12', NULL, 1),
(212, 89, 13, 4, 1, 3, 136, -1, '2020-04-22 09:54:26', '42', NULL, 1),
(213, 89, 13, 4, 1, 3, 138, -1, '2020-04-22 09:54:26', 'on', NULL, 1),
(214, 89, 13, 4, 1, 3, 140, -1, '2020-04-22 09:54:26', 'on', NULL, 1),
(215, 89, 13, 4, 1, 3, 141, -1, '2020-04-22 09:54:27', '87', NULL, 1),
(216, 89, 13, 4, 1, 3, 143, -1, '2020-04-22 09:54:27', '63', NULL, 1),
(217, 89, 13, 4, 1, 3, 145, -1, '2020-04-22 09:54:28', '41', NULL, 1),
(218, 89, 13, 4, 1, 3, 147, -1, '2020-04-22 09:54:28', '13', NULL, 1),
(219, 89, 13, 4, 1, 3, 150, -1, '2020-04-22 09:54:28', '3', NULL, 1),
(220, 89, 13, 4, 1, 3, 151, -1, '2020-04-22 09:54:29', '13', NULL, 1),
(221, 89, 13, 4, 1, 3, 154, -1, '2020-04-22 09:54:29', 'on', NULL, 1),
(222, 89, 13, 4, 1, 3, 157, -1, '2020-04-22 09:54:29', 'on', NULL, 1),
(223, 89, 13, 4, 1, 3, 158, -1, '2020-04-22 09:54:30', 'on', NULL, 1),
(224, 89, 13, 4, 1, 3, 159, 62, '2020-04-22 09:54:30', 'Pusac', NULL, 1),
(225, 89, 13, 4, 1, 3, 160, 65, '2020-04-22 09:54:31', 'Cigarete', NULL, 1),
(226, 89, 13, 4, 1, 3, 162, -1, '2020-04-22 09:54:31', '213', NULL, 1),
(227, 89, 13, 4, 1, 3, 164, -1, '2020-04-22 09:54:31', '31', NULL, 1),
(228, 89, 13, 4, 1, 3, 165, -1, '2020-04-22 09:54:32', '231', NULL, 1),
(229, 89, 13, 4, 1, 3, 167, -1, '2020-04-22 09:54:32', 'on', NULL, 1),
(230, 89, 13, 4, 1, 3, 169, -1, '2020-04-22 09:54:33', 'on', NULL, 1),
(231, 89, 13, 4, 1, 3, 171, 68, '2020-04-22 09:54:33', 'Zadovoljavajuca', NULL, 1),
(232, 89, 13, 4, 1, 3, 173, -1, '2020-04-22 09:54:33', 'on', NULL, 1),
(233, 89, 13, 4, 1, 3, 174, 70, '2020-04-22 09:54:34', 'Da', NULL, 1),
(234, 89, 13, 4, 1, 3, 176, 74, '2020-04-22 09:54:34', 'Da', NULL, 1),
(235, 89, 13, 4, 1, 3, 178, 76, '2020-04-22 09:54:34', 'Da', NULL, 1),
(236, 89, 13, 4, 1, 3, 180, -1, '2020-04-22 09:54:35', '3', NULL, 1),
(237, 89, 13, 4, 1, 3, 182, -1, '2020-04-22 09:54:35', '213', NULL, 1),
(295, 164, 5, 4, 1, 23, 282, -1, '2020-04-23 04:18:23', 'nothing much', NULL, 1),
(296, 164, 5, 4, 1, 23, 283, 185, '2020-04-23 04:18:24', '213', NULL, 1),
(297, 164, 5, 4, 1, 23, 284, 188, '2020-04-23 04:18:24', '312', NULL, 1),
(298, 164, 5, 4, 1, 23, 285, -1, '2020-04-23 04:18:25', '2020-01-01', NULL, 1),
(299, 164, 5, 4, 1, 23, 287, 191, '2020-04-23 04:18:25', 'edited nswer', NULL, 1),
(300, 164, 5, 4, 1, 23, 288, 194, '2020-04-23 04:18:25', '1321', NULL, 1),
(301, 164, 5, 4, 1, 23, 289, -1, '2020-04-23 04:18:26', '01:00', NULL, 1),
(322, 179, 7, 6, 1, 1, 1, -1, '2020-04-23 11:12:14', '194', NULL, 1),
(323, 179, 7, 6, 1, 1, 2, -1, '2020-04-23 11:12:15', '95', NULL, 1),
(324, 179, 7, 6, 1, 1, 4, -1, '2020-04-23 11:12:15', 'on', NULL, 1),
(325, 179, 7, 6, 1, 1, 5, -1, '2020-04-23 11:12:15', '88', NULL, 1),
(326, 179, 7, 6, 1, 1, 6, -1, '2020-04-23 11:12:16', '110', NULL, 1),
(327, 179, 7, 6, 1, 1, 9, 10, '2020-04-23 11:12:16', 'Bivsi Pusac', NULL, 1),
(328, 179, 7, 6, 1, 1, 10, 12, '2020-04-23 11:12:17', 'Cigarete', NULL, 1),
(329, 179, 7, 6, 1, 1, 11, -1, '2020-04-23 11:12:17', '30', NULL, 1),
(330, 179, 7, 6, 1, 1, 12, -1, '2020-04-23 11:12:18', '2', NULL, 1),
(331, 179, 7, 6, 1, 1, 13, -1, '2020-04-23 11:12:18', '5', NULL, 1),
(332, 179, 7, 6, 1, 1, 15, -1, '2020-04-23 11:12:18', 'on', NULL, 1),
(333, 179, 7, 6, 1, 1, 16, 15, '2020-04-23 11:12:19', 'Da', NULL, 1),
(334, 179, 7, 6, 1, 1, 290, 197, '2020-04-23 11:12:19', 'Prigodno', NULL, 1),
(335, 179, 7, 6, 1, 1, 291, 201, '2020-04-23 11:12:20', 'Vino', NULL, 1),
(336, 179, 7, 6, 1, 1, 292, -1, '2020-04-23 11:12:20', '1', NULL, 1),
(337, 179, 7, 6, 1, 1, 294, -1, '2020-04-23 11:12:20', 'on', NULL, 1),
(338, 179, 7, 6, 1, 1, 19, -1, '2020-04-23 11:12:21', '120', NULL, 1),
(339, 179, 7, 6, 1, 1, 20, -1, '2020-04-23 11:12:21', '110', NULL, 1),
(340, 179, 7, 6, 1, 1, 21, 18, '2020-04-23 11:12:22', 'Ne', NULL, 1),
(341, 179, 7, 6, 1, 1, 22, 19, '2020-04-23 11:12:22', 'Da', NULL, 1),
(342, 179, 7, 6, 1, 1, 23, 22, '2020-04-23 11:12:22', 'Da', NULL, 1),
(343, 179, 7, 6, 1, 1, 24, -1, '2020-04-23 11:12:23', 'Zadovoljavaju?a', NULL, 1),
(344, 179, 7, 6, 1, 1, 25, -1, '2020-04-23 11:12:23', 'on', NULL, 1),
(345, 179, 7, 6, 1, 1, 26, 25, '2020-04-23 11:12:24', 'Mali (1275-1700)', NULL, 1),
(346, 180, 7, 6, 1, 1, 1, -1, '2020-04-23 11:16:01', '198', NULL, 1),
(347, 180, 7, 6, 1, 1, 2, -1, '2020-04-23 11:16:02', '84', NULL, 1),
(348, 180, 7, 6, 1, 1, 4, -1, '2020-04-23 11:16:02', 'on', NULL, 1),
(349, 180, 7, 6, 1, 1, 5, -1, '2020-04-23 11:16:03', '60', NULL, 1),
(350, 180, 7, 6, 1, 1, 6, -1, '2020-04-23 11:16:03', '90', NULL, 1),
(351, 180, 7, 6, 1, 1, 9, 11, '2020-04-23 11:16:03', 'Nepusac', NULL, 1),
(352, 180, 7, 6, 1, 1, 16, 15, '2020-04-23 11:16:04', 'Da', NULL, 1),
(353, 180, 7, 6, 1, 1, 290, 198, '2020-04-23 11:16:04', 'Vikendom', NULL, 1),
(354, 180, 7, 6, 1, 1, 291, 203, '2020-04-23 11:16:05', 'Žestoka pica', NULL, 1),
(355, 180, 7, 6, 1, 1, 292, -1, '2020-04-23 11:16:05', '0.5', NULL, 1),
(356, 180, 7, 6, 1, 1, 19, -1, '2020-04-23 11:16:05', '111', NULL, 1),
(357, 180, 7, 6, 1, 1, 20, -1, '2020-04-23 11:16:06', '111', NULL, 1),
(358, 180, 7, 6, 1, 1, 22, 20, '2020-04-23 11:16:06', 'Ne', NULL, 1),
(359, 180, 7, 6, 1, 1, 23, 22, '2020-04-23 11:16:07', 'Da', NULL, 1),
(360, 180, 7, 6, 1, 1, 24, -1, '2020-04-23 11:16:07', 'Zadovoljavajuca', NULL, 1),
(361, 180, 7, 6, 1, 1, 26, 25, '2020-04-23 11:16:07', 'Mali (1275-1700)', NULL, 1),
(362, 188, 14, 6, 1, 1, 1, -1, '2020-04-23 11:46:25', '194', NULL, 1),
(363, 188, 14, 6, 1, 1, 2, -1, '2020-04-23 11:46:26', '95', NULL, 1),
(364, 188, 14, 6, 1, 1, 5, -1, '2020-04-23 11:46:26', '70', NULL, 1),
(365, 188, 14, 6, 1, 1, 6, -1, '2020-04-23 11:46:26', '100', NULL, 1),
(366, 188, 14, 6, 1, 1, 9, 10, '2020-04-23 11:46:27', 'Bivsi Pusac', NULL, 1),
(367, 188, 14, 6, 1, 1, 10, 12, '2020-04-23 11:46:27', 'Cigarete', NULL, 1),
(368, 188, 14, 6, 1, 1, 11, -1, '2020-04-23 11:46:27', '30', NULL, 1),
(369, 188, 14, 6, 1, 1, 12, -1, '2020-04-23 11:46:28', '2', NULL, 1),
(370, 188, 14, 6, 1, 1, 13, -1, '2020-04-23 11:46:28', '5', NULL, 1),
(371, 188, 14, 6, 1, 1, 16, 15, '2020-04-23 11:46:29', 'Da', NULL, 1),
(372, 188, 14, 6, 1, 1, 290, 198, '2020-04-23 11:46:29', 'Vikendom', NULL, 1),
(373, 188, 14, 6, 1, 1, 291, 201, '2020-04-23 11:46:29', 'Vino', NULL, 1),
(374, 188, 14, 6, 1, 1, 292, -1, '2020-04-23 11:46:30', '0.5', NULL, 1),
(375, 188, 14, 6, 1, 1, 19, -1, '2020-04-23 11:46:30', '120', NULL, 1),
(376, 188, 14, 6, 1, 1, 20, -1, '2020-04-23 11:46:30', '80', NULL, 1),
(377, 188, 14, 6, 1, 1, 21, 18, '2020-04-23 11:46:31', 'Ne', NULL, 1),
(378, 188, 14, 6, 1, 1, 22, 19, '2020-04-23 11:46:31', 'Da', NULL, 1),
(379, 188, 14, 6, 1, 1, 23, 23, '2020-04-23 11:46:31', 'Ne', NULL, 1),
(380, 188, 14, 6, 1, 1, 24, -1, '2020-04-23 11:46:32', 'Nezadovoljavajuca', NULL, 1),
(381, 188, 14, 6, 1, 1, 26, 25, '2020-04-23 11:46:32', 'Mali (1275-1700)', NULL, 1),
(382, 189, 14, 6, 1, 2, 27, -1, '2020-04-23 11:49:16', '120', NULL, 1),
(383, 189, 14, 6, 1, 2, 28, -1, '2020-04-23 11:49:16', '80', NULL, 1),
(384, 189, 14, 6, 1, 2, 29, -1, '2020-04-23 11:49:16', '123', NULL, 1),
(385, 189, 14, 6, 1, 2, 30, -1, '2020-04-23 11:49:17', '123', NULL, 1),
(386, 189, 14, 6, 1, 2, 32, -1, '2020-04-23 11:49:17', '194', NULL, 1),
(387, 189, 14, 6, 1, 2, 33, -1, '2020-04-23 11:49:18', '95', NULL, 1),
(388, 189, 14, 6, 1, 2, 37, -1, '2020-04-23 11:49:18', '122', NULL, 1),
(389, 189, 14, 6, 1, 2, 38, -1, '2020-04-23 11:49:18', '122', NULL, 1),
(390, 189, 14, 6, 1, 2, 39, -1, '2020-04-23 11:49:19', '321', NULL, 1),
(391, 189, 14, 6, 1, 2, 40, -1, '2020-04-23 11:49:19', '323', NULL, 1),
(392, 189, 14, 6, 1, 2, 41, -1, '2020-04-23 11:49:20', '232', NULL, 1),
(393, 189, 14, 6, 1, 2, 42, -1, '2020-04-23 11:49:20', '323', NULL, 1),
(394, 189, 14, 6, 1, 2, 43, -1, '2020-04-23 11:49:20', '12321', NULL, 1),
(395, 189, 14, 6, 1, 2, 44, -1, '2020-04-23 11:49:21', '123', NULL, 1),
(396, 189, 14, 6, 1, 2, 46, -1, '2020-04-23 11:49:21', 'on', NULL, 1),
(397, 189, 14, 6, 1, 2, 48, -1, '2020-04-23 11:49:22', 'on', NULL, 1),
(398, 189, 14, 6, 1, 2, 49, -1, '2020-04-23 11:49:22', '2019-04-20', NULL, 1),
(399, 189, 14, 6, 1, 2, 50, 29, '2020-04-23 11:49:23', 'Dijabeticka retinopatija – neproliferativna', NULL, 1),
(400, 189, 14, 6, 1, 2, 51, 32, '2020-04-23 11:49:23', 'Ne', NULL, 1),
(401, 189, 14, 6, 1, 2, 53, -1, '2020-04-23 11:49:23', 'on', NULL, 1),
(402, 189, 14, 6, 1, 2, 57, -1, '2020-04-23 11:49:24', '123', NULL, 1),
(403, 189, 14, 6, 1, 2, 58, -1, '2020-04-23 11:49:24', '123', NULL, 1),
(404, 189, 14, 6, 1, 2, 59, 35, '2020-04-23 11:49:25', 'Da', NULL, 1),
(405, 189, 14, 6, 1, 2, 63, 38, '2020-04-23 11:49:25', 'Bivsi pusac', NULL, 1),
(406, 189, 14, 6, 1, 2, 64, 40, '2020-04-23 11:49:25', 'Cigarete', NULL, 1),
(407, 189, 14, 6, 1, 2, 65, -1, '2020-04-23 11:49:26', '30', NULL, 1),
(408, 189, 14, 6, 1, 2, 66, -1, '2020-04-23 11:49:26', '2', NULL, 1),
(409, 189, 14, 6, 1, 2, 67, -1, '2020-04-23 11:49:27', '5', NULL, 1),
(410, 189, 14, 6, 1, 2, 70, 43, '2020-04-23 11:49:27', 'Da', NULL, 1),
(411, 189, 14, 6, 1, 2, 71, 46, '2020-04-23 11:49:27', 'Vikendom', NULL, 1),
(412, 189, 14, 6, 1, 2, 72, 49, '2020-04-23 11:49:28', 'Vino', NULL, 1),
(413, 189, 14, 6, 1, 2, 73, -1, '2020-04-23 11:49:28', '0.5', NULL, 1),
(414, 189, 14, 6, 1, 2, 76, 53, '2020-04-23 11:49:29', 'Nezadovoljavajuca', NULL, 1),
(415, 189, 14, 6, 1, 2, 78, 55, '2020-04-23 11:49:29', 'Ne', NULL, 1),
(416, 189, 14, 6, 1, 2, 79, 57, '2020-04-23 11:49:29', 'Ne', NULL, 1),
(417, 189, 14, 6, 1, 2, 80, 59, '2020-04-23 11:49:30', 'Ne', NULL, 1),
(418, 191, 14, 6, 1, 3, 54, -1, '2020-04-23 11:51:38', '194', NULL, 1),
(419, 191, 14, 6, 1, 3, 56, -1, '2020-04-23 11:51:39', '95', NULL, 1),
(420, 191, 14, 6, 1, 3, 118, -1, '2020-04-23 11:51:39', '80', NULL, 1),
(421, 191, 14, 6, 1, 3, 120, -1, '2020-04-23 11:51:39', '100', NULL, 1),
(422, 191, 14, 6, 1, 3, 127, 61, '2020-04-23 11:51:40', 'Ne', NULL, 1),
(423, 191, 14, 6, 1, 3, 129, -1, '2020-04-23 11:51:40', '120', NULL, 1),
(424, 191, 14, 6, 1, 3, 131, -1, '2020-04-23 11:51:40', '80', NULL, 1),
(425, 191, 14, 6, 1, 3, 133, -1, '2020-04-23 11:51:41', '80', NULL, 1),
(426, 191, 14, 6, 1, 3, 136, -1, '2020-04-23 11:51:41', '80', NULL, 1),
(427, 191, 14, 6, 1, 3, 140, -1, '2020-04-23 11:51:41', 'on', NULL, 1),
(428, 191, 14, 6, 1, 3, 141, -1, '2020-04-23 11:51:42', '120', NULL, 1),
(429, 191, 14, 6, 1, 3, 143, -1, '2020-04-23 11:51:42', '120', NULL, 1),
(430, 191, 14, 6, 1, 3, 145, -1, '2020-04-23 11:51:43', '120', NULL, 1),
(431, 191, 14, 6, 1, 3, 147, -1, '2020-04-23 11:51:43', '120', NULL, 1),
(432, 191, 14, 6, 1, 3, 150, -1, '2020-04-23 11:51:43', '120', NULL, 1),
(433, 191, 14, 6, 1, 3, 151, -1, '2020-04-23 11:51:44', '120', NULL, 1),
(434, 191, 14, 6, 1, 3, 157, -1, '2020-04-23 11:51:44', 'on', NULL, 1),
(435, 191, 14, 6, 1, 3, 159, 63, '2020-04-23 11:51:44', 'Bivsi pusac', NULL, 1),
(436, 191, 14, 6, 1, 3, 160, 65, '2020-04-23 11:51:45', 'Cigarete', NULL, 1),
(437, 191, 14, 6, 1, 3, 162, -1, '2020-04-23 11:51:45', '30', NULL, 1),
(438, 191, 14, 6, 1, 3, 164, -1, '2020-04-23 11:51:46', '2', NULL, 1),
(439, 191, 14, 6, 1, 3, 165, -1, '2020-04-23 11:51:46', '5', NULL, 1),
(440, 191, 14, 6, 1, 3, 169, -1, '2020-04-23 11:51:46', 'on', NULL, 1),
(441, 191, 14, 6, 1, 3, 171, 69, '2020-04-23 11:51:47', 'Nezadovoljavajuca', NULL, 1),
(442, 191, 14, 6, 1, 3, 173, -1, '2020-04-23 11:51:47', 'on', NULL, 1),
(443, 191, 14, 6, 1, 3, 174, 70, '2020-04-23 11:51:47', 'Da', NULL, 1),
(444, 191, 14, 6, 1, 3, 175, 73, '2020-04-23 11:51:48', 'Ne', NULL, 1),
(445, 191, 14, 6, 1, 3, 176, 75, '2020-04-23 11:51:48', 'Ne', NULL, 1),
(446, 191, 14, 6, 1, 3, 178, 77, '2020-04-23 11:51:49', 'Ne', NULL, 1),
(447, 191, 14, 6, 1, 3, 180, -1, '2020-04-23 11:51:49', '50', NULL, 1),
(448, 191, 14, 6, 1, 3, 182, -1, '2020-04-23 11:51:49', '50', NULL, 1),
(449, 192, 14, 6, 1, 4, 82, -1, '2020-04-23 11:53:34', '120', NULL, 1),
(450, 192, 14, 6, 1, 4, 83, -1, '2020-04-23 11:53:34', '120', NULL, 1),
(451, 192, 14, 6, 1, 4, 84, -1, '2020-04-23 11:53:34', '120', NULL, 1),
(452, 192, 14, 6, 1, 4, 85, -1, '2020-04-23 11:53:35', '120', NULL, 1),
(453, 192, 14, 6, 1, 4, 86, 79, '2020-04-23 11:53:35', 'Bivsi pusac', NULL, 1),
(454, 192, 14, 6, 1, 4, 87, 81, '2020-04-23 11:53:36', 'Cigarete', NULL, 1),
(455, 192, 14, 6, 1, 4, 88, -1, '2020-04-23 11:53:36', '30', NULL, 1),
(456, 192, 14, 6, 1, 4, 89, -1, '2020-04-23 11:53:36', '2', NULL, 1),
(457, 192, 14, 6, 1, 4, 90, -1, '2020-04-23 11:53:37', '5', NULL, 1),
(458, 192, 14, 6, 1, 4, 92, 84, '2020-04-23 11:53:37', 'Da', NULL, 1),
(459, 192, 14, 6, 1, 4, 93, -1, '2020-04-23 11:53:38', '0001-05-04', NULL, 1),
(460, 192, 14, 6, 1, 4, 94, 87, '2020-04-23 11:53:38', 'Da', NULL, 1),
(461, 192, 14, 6, 1, 4, 95, -1, '2020-04-23 11:53:39', '0555-05-05', NULL, 1),
(462, 192, 14, 6, 1, 4, 96, -1, '2020-04-23 11:53:39', 'on', NULL, 1),
(463, 192, 14, 6, 1, 4, 97, -1, '2020-04-23 11:53:39', '2020-04-16', NULL, 1),
(464, 192, 14, 6, 1, 4, 98, -1, '2020-04-23 11:53:40', 'on', NULL, 1),
(465, 192, 14, 6, 1, 4, 99, -1, '2020-04-23 11:53:40', '2020-04-16', NULL, 1),
(466, 192, 14, 6, 1, 4, 101, -1, '2020-04-23 11:53:41', 'on', NULL, 1),
(467, 192, 14, 6, 1, 4, 102, -1, '2020-04-23 11:53:41', '2020-04-18', NULL, 1),
(468, 193, 14, 6, 1, 5, 104, -1, '2020-04-23 11:55:15', '50', NULL, 1),
(469, 193, 14, 6, 1, 5, 104, -1, '2020-04-23 11:55:16', '120', NULL, 1),
(470, 193, 14, 6, 1, 5, 105, -1, '2020-04-23 11:55:16', '60', NULL, 1),
(471, 193, 14, 6, 1, 5, 106, -1, '2020-04-23 11:55:17', '90', NULL, 1),
(472, 193, 14, 6, 1, 5, 107, 91, '2020-04-23 11:55:17', 'Ne', NULL, 1),
(473, 193, 14, 6, 1, 5, 109, -1, '2020-04-23 11:55:17', '123', NULL, 1),
(474, 193, 14, 6, 1, 5, 110, -1, '2020-04-23 11:55:18', '123', NULL, 1),
(475, 194, 14, 6, 1, 7, 190, -1, '2020-04-23 11:57:04', '1321', NULL, 1),
(476, 194, 14, 6, 1, 7, 191, -1, '2020-04-23 11:57:05', '13132', NULL, 1),
(477, 197, 14, 6, 1, 8, 113, -1, '2020-04-23 12:07:58', '194', NULL, 1),
(478, 197, 14, 6, 1, 8, 114, -1, '2020-04-23 12:07:59', '95', NULL, 1),
(479, 197, 14, 6, 1, 8, 296, -1, '2020-04-23 12:07:59', '90', NULL, 1),
(480, 197, 14, 6, 1, 8, 297, -1, '2020-04-23 12:08:00', '60', NULL, 1),
(481, 197, 14, 6, 1, 8, 121, 96, '2020-04-23 12:08:00', 'Da', NULL, 1),
(482, 197, 14, 6, 1, 8, 124, 97, '2020-04-23 12:08:00', 'Da', NULL, 1),
(483, 197, 14, 6, 1, 8, 126, -1, '2020-04-23 12:08:01', '120', NULL, 1),
(484, 197, 14, 6, 1, 8, 126, -1, '2020-04-23 12:08:01', '90', NULL, 1),
(485, 197, 14, 6, 1, 8, 128, -1, '2020-04-23 12:08:02', '120', NULL, 1),
(486, 197, 14, 6, 1, 8, 130, -1, '2020-04-23 12:08:02', '120', NULL, 1),
(487, 197, 14, 6, 1, 8, 132, -1, '2020-04-23 12:08:03', '120', NULL, 1),
(488, 197, 14, 6, 1, 8, 134, -1, '2020-04-23 12:08:03', '120', NULL, 1),
(489, 197, 14, 6, 1, 8, 135, -1, '2020-04-23 12:08:03', '120', NULL, 1),
(490, 197, 14, 6, 1, 8, 137, -1, '2020-04-23 12:08:04', '120', NULL, 1),
(491, 197, 14, 6, 1, 8, 139, 100, '2020-04-23 12:08:04', 'Ne', NULL, 1),
(492, 197, 14, 6, 1, 8, 142, 102, '2020-04-23 12:08:05', 'Ne', NULL, 1),
(493, 197, 14, 6, 1, 8, 144, 104, '2020-04-23 12:08:05', 'Ne', NULL, 1),
(494, 197, 14, 6, 1, 8, 146, 106, '2020-04-23 12:08:05', 'Ne', NULL, 1),
(495, 197, 14, 6, 1, 8, 148, -1, '2020-04-23 12:08:06', '5', NULL, 1),
(496, 197, 14, 6, 1, 8, 149, -1, '2020-04-23 12:08:06', '30', NULL, 1),
(497, 198, 14, 6, 1, 9, 152, -1, '2020-04-23 12:10:55', '2020-04-23', NULL, 1),
(498, 198, 14, 6, 1, 9, 153, -1, '2020-04-23 12:10:55', '95', NULL, 1),
(499, 198, 14, 6, 1, 9, 155, -1, '2020-04-23 12:10:56', '195', NULL, 1),
(500, 198, 14, 6, 1, 9, 156, -1, '2020-04-23 12:10:56', '60', NULL, 1),
(501, 198, 14, 6, 1, 9, 161, 107, '2020-04-23 12:10:57', 'Da', NULL, 1),
(502, 198, 14, 6, 1, 9, 163, 110, '2020-04-23 12:10:57', 'Uglavnom ostali zasladjeni napitci', NULL, 1),
(503, 198, 14, 6, 1, 9, 166, 112, '2020-04-23 12:10:57', 'Ne', NULL, 1),
(504, 198, 14, 6, 1, 9, 168, -1, '2020-04-23 12:10:58', '5', NULL, 1),
(505, 198, 14, 6, 1, 9, 170, 114, '2020-04-23 12:10:58', 'Ne', NULL, 1),
(506, 198, 14, 6, 1, 9, 172, -1, '2020-04-23 12:10:58', 'on', NULL, 1),
(507, 198, 14, 6, 1, 9, 177, -1, '2020-04-23 12:10:59', 'Testtstststs', NULL, 1),
(508, 199, 14, 6, 1, 10, 201, -1, '2020-04-23 12:12:43', '14', NULL, 1),
(509, 199, 14, 6, 1, 10, 204, 115, '2020-04-23 12:12:43', 'Lice', NULL, 1),
(510, 14, 204, 6, 1, 0, 61, -1, '2020-04-23 12:12:44', 'Pazuh', NULL, 1),
(511, 199, 14, 6, 1, 10, 206, 120, '2020-04-23 12:12:44', '1x godisnje', NULL, 1),
(512, 199, 14, 6, 1, 10, 208, 125, '2020-04-23 12:12:44', 'Ne', NULL, 1),
(513, 199, 14, 6, 1, 10, 209, 127, '2020-04-23 12:12:45', 'Ne', NULL, 1),
(514, 199, 14, 6, 1, 10, 210, 129, '2020-04-23 12:12:45', 'Ne', NULL, 1),
(515, 199, 14, 6, 1, 10, 211, 134, '2020-04-23 12:12:46', 'Antimikotici', NULL, 1),
(516, 199, 14, 6, 1, 10, 212, -1, '2020-04-23 12:12:46', 'Ne znam', NULL, 1),
(517, 199, 14, 6, 1, 10, 213, 135, '2020-04-23 12:12:46', 'Da', NULL, 1),
(518, 199, 14, 6, 1, 10, 214, 137, '2020-04-23 12:12:47', 'O prehrani', NULL, 1),
(519, 199, 14, 6, 1, 10, 215, -1, '2020-04-23 12:12:47', 'asdasdasd', NULL, 1),
(520, 200, 14, 6, 1, 11, 196, -1, '2020-04-23 12:13:50', '195', NULL, 1),
(521, 200, 14, 6, 1, 11, 197, -1, '2020-04-23 12:13:50', '80', NULL, 1),
(522, 200, 14, 6, 1, 11, 198, -1, '2020-04-23 12:13:51', '12', NULL, 1),
(523, 200, 14, 6, 1, 11, 199, -1, '2020-04-23 12:13:51', '123', NULL, 1),
(524, 200, 14, 6, 1, 11, 200, -1, '2020-04-23 12:13:52', '123123', NULL, 1),
(525, 200, 14, 6, 1, 11, 202, 142, '2020-04-23 12:13:52', 'Ne', NULL, 1),
(526, 200, 14, 6, 1, 11, 203, 144, '2020-04-23 12:13:52', 'Ne', NULL, 1),
(527, 200, 14, 6, 1, 11, 205, 145, '2020-04-23 12:13:53', 'Da', NULL, 1),
(528, 200, 14, 6, 1, 11, 207, 147, '2020-04-23 12:13:53', 'Pozitivno', NULL, 1),
(529, 201, 14, 6, 1, 10, 201, -1, '2020-04-23 12:15:58', '14', NULL, 1),
(530, 201, 14, 6, 1, 10, 204, 117, '2020-04-23 12:15:58', 'Trup', NULL, 1),
(531, 201, 14, 6, 1, 10, 206, 119, '2020-04-23 12:15:59', 'Manje od 1x godisnje', NULL, 1),
(532, 201, 14, 6, 1, 10, 208, 124, '2020-04-23 12:15:59', 'Da', NULL, 1),
(533, 201, 14, 6, 1, 10, 209, 126, '2020-04-23 12:15:59', 'Da', NULL, 1),
(534, 201, 14, 6, 1, 10, 210, 129, '2020-04-23 12:16:00', 'Ne', NULL, 1),
(535, 201, 14, 6, 1, 10, 211, 133, '2020-04-23 12:16:00', 'Antibiotici', NULL, 1),
(536, 201, 14, 6, 1, 10, 212, -1, '2020-04-23 12:16:01', '1231', NULL, 1),
(537, 201, 14, 6, 1, 10, 213, 136, '2020-04-23 12:16:01', 'Ne', NULL, 1),
(538, 201, 14, 6, 1, 10, 214, 140, '2020-04-23 12:16:01', 'O lijecenju', NULL, 1),
(539, 201, 14, 6, 1, 10, 215, -1, '2020-04-23 12:16:02', 'TEstststs', NULL, 1),
(540, 202, 5, 4, 1, 10, 204, 118, '2020-04-23 12:31:44', 'Udovi', NULL, 1),
(541, 5, 204, 4, 1, 0, 61, -1, '2020-04-23 12:31:45', 'daa12', NULL, 1),
(542, 202, 5, 4, 1, 10, 206, 122, '2020-04-23 12:31:45', '5-6x godisnje', NULL, 1),
(543, 202, 5, 4, 1, 10, 208, 124, '2020-04-23 12:31:45', 'Da', NULL, 1),
(544, 202, 5, 4, 1, 10, 209, 126, '2020-04-23 12:31:46', 'Da', NULL, 1),
(545, 202, 5, 4, 1, 10, 210, 129, '2020-04-23 12:31:46', 'Ne', NULL, 1),
(546, 202, 5, 4, 1, 10, 211, 130, '2020-04-23 12:31:47', 'Neutralni pripravci', NULL, 1),
(547, 5, 211, 4, 1, 0, 63, -1, '2020-04-23 12:31:47', 'asdds', NULL, 1),
(548, 202, 5, 4, 1, 10, 212, -1, '2020-04-23 12:31:47', 'sda', NULL, 1),
(549, 202, 5, 4, 1, 10, 213, 136, '2020-04-23 12:31:48', 'Ne', NULL, 1),
(550, 202, 5, 4, 1, 10, 214, 139, '2020-04-23 12:31:48', 'O stetnim utjecajima', NULL, 1),
(551, 5, 214, 4, 1, 0, 64, -1, '2020-04-23 12:31:48', 'asd', NULL, 1),
(552, 202, 5, 4, 1, 10, 215, -1, '2020-04-23 12:31:49', 'dsaasdas', NULL, 1),
(553, 205, 5, 4, 1, 10, 201, -1, '2020-04-23 12:38:46', '321', NULL, 1),
(554, 205, 5, 4, 1, 10, 204, 118, '2020-04-23 12:38:47', 'Udovi', NULL, 1),
(555, 5, 204, 4, 1, 0, 61, -1, '2020-04-23 12:38:47', 'ostalo 1', NULL, 1),
(556, 205, 5, 4, 1, 10, 206, 119, '2020-04-23 12:38:48', 'Manje od 1x godisnje', NULL, 1),
(557, 205, 5, 4, 1, 10, 208, 125, '2020-04-23 12:38:48', 'Ne', NULL, 1),
(558, 205, 5, 4, 1, 10, 209, 126, '2020-04-23 12:38:49', 'Da', NULL, 1),
(559, 205, 5, 4, 1, 10, 210, 128, '2020-04-23 12:38:49', 'Da', NULL, 1),
(560, 205, 5, 4, 1, 10, 211, 134, '2020-04-23 12:38:49', 'Antimikotici', NULL, 1),
(561, 5, 211, 4, 1, 0, 63, -1, '2020-04-23 12:38:50', 'ostalo 3', NULL, 1),
(562, 205, 5, 4, 1, 10, 212, -1, '2020-04-23 12:38:50', 'das', NULL, 1),
(563, 205, 5, 4, 1, 10, 213, 136, '2020-04-23 12:38:51', 'Ne', NULL, 1),
(564, 205, 5, 4, 1, 10, 214, 138, '2020-04-23 12:38:51', 'O njezi i higijeni', NULL, 1),
(565, 5, 214, 4, 1, 0, 64, -1, '2020-04-23 12:38:52', 'ostalo 5', NULL, 1),
(566, 205, 5, 4, 1, 10, 215, -1, '2020-04-23 12:38:52', 'napomenaaa', NULL, 1),
(567, 206, 5, 4, 1, 10, 201, -1, '2020-04-23 12:40:57', '12', NULL, 1),
(568, 206, 5, 4, 1, 10, 204, -1, '2020-04-23 12:40:57', 'ostalo 1', NULL, 1),
(569, 206, 5, 4, 1, 10, 206, 120, '2020-04-23 12:40:58', '1x godisnje', NULL, 1),
(570, 206, 5, 4, 1, 10, 208, 124, '2020-04-23 12:40:58', 'Da', NULL, 1),
(571, 206, 5, 4, 1, 10, 209, 127, '2020-04-23 12:40:58', 'Ne', NULL, 1),
(572, 206, 5, 4, 1, 10, 210, 129, '2020-04-23 12:40:59', 'Ne', NULL, 1),
(573, 206, 5, 4, 1, 10, 211, -1, '2020-04-23 12:40:59', 'ostalo 3', NULL, 1),
(574, 206, 5, 4, 1, 10, 212, -1, '2020-04-23 12:41:00', 'sda', NULL, 1),
(575, 206, 5, 4, 1, 10, 213, 136, '2020-04-23 12:41:00', 'Ne', NULL, 1),
(576, 206, 5, 4, 1, 10, 214, -1, '2020-04-23 12:41:00', 'ostalo 6', NULL, 1),
(577, 206, 5, 4, 1, 10, 215, -1, '2020-04-23 12:41:01', 'napomenaaaaa', NULL, 1),
(578, 208, 5, 4, 1, 23, 282, -1, '2020-04-23 12:48:49', 'nothign', NULL, 1),
(579, 208, 5, 4, 1, 23, 284, 190, '2020-04-23 12:48:49', '41d', NULL, 1),
(580, 209, 5, 4, 1, 23, 284, 188, '2020-04-23 12:49:40', '312', NULL, 1),
(581, 214, 5, 4, 1, 23, 282, -1, '2020-04-23 13:14:01', 'nj', NULL, 1),
(582, 232, 5, 4, 1, 23, 284, 187, '2020-04-23 16:56:57', '1', NULL, 1),
(583, 232, 5, 4, 1, 23, 284, 188, '2020-04-23 16:56:58', '312', NULL, 1),
(584, 232, 5, 4, 1, 23, 284, 189, '2020-04-23 16:56:58', '12', NULL, 1),
(585, 232, 5, 4, 1, 23, 284, 190, '2020-04-23 16:56:59', '41d', NULL, 1),
(586, 233, 5, 4, 1, 23, 282, -1, '2020-04-23 17:02:38', 'Nothing much,', NULL, 1),
(587, 233, 5, 4, 1, 23, 283, -1, '2020-04-23 17:02:39', 'Ostalo 1', NULL, 1),
(588, 233, 5, 4, 1, 23, 284, 187, '2020-04-23 17:02:39', '1', NULL, 1),
(589, 233, 5, 4, 1, 23, 284, 189, '2020-04-23 17:02:40', '12', NULL, 1),
(590, 233, 5, 4, 1, 23, 284, 190, '2020-04-23 17:02:40', '41d', NULL, 1),
(591, 233, 5, 4, 1, 23, 285, -1, '2020-04-23 17:02:41', '2019-01-01', NULL, 1),
(592, 233, 5, 4, 1, 23, 287, 191, '2020-04-23 17:02:42', 'edited nswer', NULL, 1),
(593, 233, 5, 4, 1, 23, 288, 194, '2020-04-23 17:02:42', '1321', NULL, 1),
(594, 233, 5, 4, 1, 23, 289, -1, '2020-04-23 17:02:43', '01:00', NULL, 1),
(595, 234, 5, 4, 1, 23, 283, -1, '2020-04-23 17:05:02', 'Ostaloodad 2', NULL, 1),
(596, 234, 5, 4, 1, 23, 284, 187, '2020-04-23 17:05:02', '1', NULL, 1),
(597, 234, 5, 4, 1, 23, 284, 188, '2020-04-23 17:05:03', '312', NULL, 1),
(598, 234, 5, 4, 1, 23, 284, 190, '2020-04-23 17:05:03', '41d', NULL, 1),
(599, 234, 5, 4, 1, 23, 285, -1, '2020-04-23 17:05:04', '2020-01-01', NULL, 1),
(600, 234, 5, 4, 1, 23, 287, 193, '2020-04-23 17:05:04', '3111', NULL, 1),
(601, 234, 5, 4, 1, 23, 288, 195, '2020-04-23 17:05:05', '321', NULL, 1),
(602, 234, 5, 4, 1, 23, 289, -1, '2020-04-23 17:05:05', '01:00', NULL, 1),
(603, 236, 5, 4, 1, 23, 283, -1, '2020-04-23 17:08:46', 'kl', NULL, 1),
(604, 237, 5, 4, 1, 23, 282, -1, '2020-04-23 17:10:34', 'nthg much', NULL, 1),
(605, 237, 5, 4, 1, 23, 283, 184, '2020-04-23 17:10:35', '13221', NULL, 1),
(606, 237, 5, 4, 1, 23, 283, 186, '2020-04-23 17:10:36', 'dsad', NULL, 1),
(607, 237, 5, 4, 1, 23, 283, -1, '2020-04-23 17:10:37', 'ostaloo 31', NULL, 1),
(608, 237, 5, 4, 1, 23, 284, 187, '2020-04-23 17:10:38', '1', NULL, 1),
(609, 237, 5, 4, 1, 23, 284, 188, '2020-04-23 17:10:38', '312', NULL, 1),
(610, 237, 5, 4, 1, 23, 284, 189, '2020-04-23 17:10:39', '12', NULL, 1),
(611, 237, 5, 4, 1, 23, 285, -1, '2020-04-23 17:10:40', '2020-01-01', NULL, 1),
(612, 237, 5, 4, 1, 23, 287, 193, '2020-04-23 17:10:40', '3111', NULL, 1),
(613, 237, 5, 4, 1, 23, 288, 194, '2020-04-23 17:10:41', '1321', NULL, 1),
(614, 237, 5, 4, 1, 23, 289, -1, '2020-04-23 17:10:42', '01:00', NULL, 1),
(615, 237, 5, 4, 1, 10, 201, -1, '2020-04-23 17:12:34', '312', NULL, 1),
(616, 237, 5, 4, 1, 10, 204, 115, '2020-04-23 17:12:35', 'Lice', NULL, 1),
(617, 237, 5, 4, 1, 10, 204, 116, '2020-04-23 17:12:36', 'Vrat', NULL, 1),
(618, 237, 5, 4, 1, 10, 204, 117, '2020-04-23 17:12:36', 'Trup', NULL, 1),
(619, 237, 5, 4, 1, 10, 204, -1, '2020-04-23 17:12:37', 'ostalo 1', NULL, 1),
(620, 237, 5, 4, 1, 10, 206, 120, '2020-04-23 17:12:37', '1x godisnje', NULL, 1),
(621, 237, 5, 4, 1, 10, 208, 124, '2020-04-23 17:12:38', 'Da', NULL, 1),
(622, 237, 5, 4, 1, 10, 209, 127, '2020-04-23 17:12:38', 'Ne', NULL, 1),
(623, 237, 5, 4, 1, 10, 210, 128, '2020-04-23 17:12:39', 'Da', NULL, 1),
(624, 237, 5, 4, 1, 10, 211, 130, '2020-04-23 17:12:40', 'Neutralni pripravci', NULL, 1),
(625, 237, 5, 4, 1, 10, 211, 131, '2020-04-23 17:12:41', 'Kortikosteroidni pripravci', NULL, 1),
(626, 237, 5, 4, 1, 10, 211, 132, '2020-04-23 17:12:43', 'Antihistaminici', NULL, 1),
(627, 237, 5, 4, 1, 10, 211, -1, '2020-04-23 17:12:43', 'ostalooo 3', NULL, 1),
(628, 237, 5, 4, 1, 10, 212, -1, '2020-04-23 17:12:44', 'ji[k', NULL, 1),
(629, 237, 5, 4, 1, 10, 213, 135, '2020-04-23 17:12:45', 'Da', NULL, 1),
(630, 237, 5, 4, 1, 10, 214, 137, '2020-04-23 17:12:46', 'O prehrani', NULL, 1),
(631, 237, 5, 4, 1, 10, 214, 138, '2020-04-23 17:12:48', 'O njezi i higijeni', NULL, 1),
(632, 237, 5, 4, 1, 10, 214, 139, '2020-04-23 17:12:49', 'O stetnim utjecajima', NULL, 1),
(633, 237, 5, 4, 1, 10, 214, -1, '2020-04-23 17:12:50', 'ostaloo 1331', NULL, 1),
(634, 237, 5, 4, 1, 10, 215, -1, '2020-04-23 17:12:51', 'adkodasda ,sla l s;ld', NULL, 1),
(635, 240, 5, 4, 1, 10, 201, -1, '2020-04-23 17:16:43', '69', NULL, 1),
(636, 240, 5, 4, 1, 10, 204, 115, '2020-04-23 17:16:44', 'Lice', NULL, 1),
(637, 240, 5, 4, 1, 10, 204, 116, '2020-04-23 17:16:45', 'Vrat', NULL, 1),
(638, 240, 5, 4, 1, 10, 204, 117, '2020-04-23 17:16:46', 'Trup', NULL, 1),
(639, 240, 5, 4, 1, 10, 204, -1, '2020-04-23 17:16:46', 'Ostalo 12', NULL, 1),
(640, 240, 5, 4, 1, 10, 206, -1, '2020-04-23 17:16:47', 'Ostalo radio', NULL, 1),
(641, 240, 5, 4, 1, 10, 208, 124, '2020-04-23 17:16:48', 'Da', NULL, 1),
(642, 240, 5, 4, 1, 10, 209, 126, '2020-04-23 17:16:48', 'Da', NULL, 1),
(643, 240, 5, 4, 1, 10, 210, 129, '2020-04-23 17:16:49', 'Ne', NULL, 1),
(644, 240, 5, 4, 1, 10, 211, 130, '2020-04-23 17:16:49', 'Neutralni pripravci', NULL, 1),
(645, 240, 5, 4, 1, 10, 211, 131, '2020-04-23 17:16:50', 'Kortikosteroidni pripravci', NULL, 1),
(646, 240, 5, 4, 1, 10, 211, 132, '2020-04-23 17:16:51', 'Antihistaminici', NULL, 1),
(647, 240, 5, 4, 1, 10, 211, 133, '2020-04-23 17:16:51', 'Antibiotici', NULL, 1),
(648, 240, 5, 4, 1, 10, 211, -1, '2020-04-23 17:16:52', 'ostaloo 12', NULL, 1),
(649, 240, 5, 4, 1, 10, 212, -1, '2020-04-23 17:16:53', '213', NULL, 1),
(650, 240, 5, 4, 1, 10, 213, 135, '2020-04-23 17:16:53', 'Da', NULL, 1),
(651, 240, 5, 4, 1, 10, 214, 137, '2020-04-23 17:16:54', 'O prehrani', NULL, 1),
(652, 240, 5, 4, 1, 10, 214, 138, '2020-04-23 17:16:54', 'O njezi i higijeni', NULL, 1),
(653, 240, 5, 4, 1, 10, 214, 139, '2020-04-23 17:16:55', 'O stetnim utjecajima', NULL, 1),
(654, 240, 5, 4, 1, 10, 214, -1, '2020-04-23 17:16:58', 'ostalooo', NULL, 1),
(655, 240, 5, 4, 1, 10, 215, -1, '2020-04-23 17:16:59', 'nospskdo sas ', NULL, 1),
(656, 242, 5, 4, 1, 10, 206, 121, '2020-04-23 17:21:16', '2-4x godisnje', NULL, 1),
(657, 5, 206, 4, 1, 0, 61, -1, '2020-04-23 17:21:16', 'other 213', NULL, 1),
(658, 245, 5, 4, 1, 10, 206, 119, '2020-04-23 17:25:35', 'Manje od 1x godisnje', NULL, 1),
(659, 5, 206, 4, 1, 0, 61, -1, '2020-04-23 17:25:36', 'ostaloo', NULL, 1),
(660, 246, 5, 4, 1, 10, 206, 121, '2020-04-23 17:26:29', '2-4x godisnje', NULL, 1),
(661, 5, 206, 4, 1, 0, 61, -1, '2020-04-23 17:26:30', 'sdaa ostal', NULL, 1),
(662, 247, 5, 4, 1, 10, 206, 120, '2020-04-23 17:27:39', '1x godisnje', NULL, 1),
(663, 5, 206, 4, 1, 0, 61, -1, '2020-04-23 17:27:40', 'das as o', NULL, 1),
(664, 248, 5, 4, 1, 10, 206, 122, '2020-04-23 17:29:43', '5-6x godisnje', NULL, 1),
(665, 248, 5, 4, 1, 10, 206, -1, '2020-04-23 17:29:44', 'adsdas asads', NULL, 1),
(666, 249, 5, 4, 1, 10, 206, 123, '2020-04-23 17:30:33', 'Vise od 6x godisnje', NULL, 1),
(667, 249, 5, 4, 1, 10, 206, -1, '2020-04-23 17:30:33', 'ostaloo', NULL, 1);

-- --------------------------------------------------------

--
-- Table structure for table `patient_record_history`
--

CREATE TABLE `patient_record_history` (
  `id` int(11) NOT NULL,
  `date_submitted` datetime NOT NULL,
  `patient_id` int(11) NOT NULL,
  `pharmacist_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `patient_record_history`
--

INSERT INTO `patient_record_history` (`id`, `date_submitted`, `patient_id`, `pharmacist_id`) VALUES
(1, '2020-04-13 00:00:00', 1, 4),
(2, '2020-04-14 07:54:08', 1, 4),
(3, '2020-04-14 07:55:32', 1, 4),
(4, '2020-04-14 07:57:47', 1, 4),
(5, '2020-04-14 08:02:43', 1, 4),
(6, '2020-04-14 08:04:58', 1, 4),
(7, '2020-04-14 08:06:20', 1, 4),
(8, '2020-04-14 08:07:42', 1, 4),
(9, '2020-04-14 08:08:15', 1, 4),
(10, '2020-04-14 08:08:19', 1, 4),
(11, '2020-04-14 08:08:23', 1, 4),
(12, '2020-04-14 08:20:23', 1, 4),
(13, '2020-04-14 08:20:38', 1, 4),
(14, '2020-04-14 08:21:43', 1, 4),
(15, '2020-04-14 08:22:32', 1, 4),
(16, '2020-04-14 08:22:59', 2, 4),
(17, '2020-04-14 08:23:31', 2, 4),
(18, '2020-04-14 08:23:38', 1, 4),
(19, '2020-04-14 08:24:47', 1, 4),
(20, '2020-04-14 08:25:31', 1, 4),
(21, '2020-04-14 08:28:34', 1, 4),
(22, '2020-04-14 08:28:44', 1, 4),
(23, '2020-04-14 08:30:00', 1, 4),
(24, '2020-04-14 08:30:03', 1, 4),
(25, '2020-04-14 08:30:48', 1, 4),
(26, '2020-04-14 08:31:32', 1, 4),
(27, '2020-04-14 08:31:39', 1, 4),
(28, '2020-04-14 08:32:25', 1, 4),
(29, '2020-04-14 08:33:09', 1, 4),
(30, '2020-04-14 08:33:20', 1, 4),
(31, '2020-04-14 08:34:21', 1, 4),
(32, '2020-04-14 08:35:04', 1, 4),
(33, '2020-04-14 08:36:07', 1, 4),
(34, '2020-04-14 08:37:20', 1, 4),
(35, '2020-04-14 08:37:57', 1, 4),
(36, '2020-04-14 08:40:59', 1, 4),
(37, '2020-04-14 08:41:04', 1, 4),
(38, '2020-04-14 08:42:09', 1, 4),
(39, '2020-04-14 08:43:14', 1, 4),
(40, '2020-04-14 08:43:43', 1, 4),
(41, '2020-04-14 08:43:57', 1, 4),
(42, '2020-04-14 08:44:33', 1, 4),
(43, '2020-04-14 08:45:18', 1, 4),
(44, '2020-04-14 09:00:11', 2, 4),
(45, '2020-04-14 09:34:45', 5, 6),
(46, '2020-04-14 09:40:50', 1, 4),
(47, '2020-04-14 09:42:50', 1, 4),
(48, '2020-04-14 09:45:06', 5, 4),
(49, '2020-04-14 09:48:46', 5, 4),
(50, '2020-04-14 10:15:44', 5, 4),
(51, '2020-04-14 10:35:29', 8, 4),
(52, '2020-04-14 11:22:20', 3, 4),
(53, '2020-04-14 11:29:19', 7, 4),
(54, '2020-04-14 12:48:57', 5, 6),
(55, '2020-04-14 12:51:15', 5, 6),
(56, '2020-04-14 12:58:00', 9, 6),
(57, '2020-04-14 13:14:06', 2, 4),
(60, '2020-04-16 12:47:10', 5, 6),
(61, '2020-04-17 11:54:46', 3, 4),
(62, '2020-04-18 08:13:13', 8, 4),
(63, '2020-04-18 08:39:38', 1, 4),
(64, '2020-04-18 08:54:24', 5, 6),
(65, '2020-04-18 09:00:23', 5, 6),
(66, '2020-04-20 12:57:35', 12, 4),
(69, '2020-04-20 12:57:56', 12, 4),
(70, '2020-04-20 12:59:44', 12, 4),
(71, '2020-04-20 13:00:46', 12, 4),
(72, '2020-04-20 16:33:44', 5, 6),
(76, '2020-04-21 05:37:53', 13, 6),
(77, '2020-04-21 07:27:02', 5, 4),
(78, '2020-04-21 07:32:13', 5, 4),
(79, '2020-04-22 06:49:01', 12, 4),
(80, '2020-04-22 06:49:50', 2, 4),
(81, '2020-04-22 06:50:26', 6, 4),
(82, '2020-04-22 06:51:19', 4, 4),
(83, '2020-04-22 07:05:13', 9, 4),
(84, '2020-04-22 07:06:09', 9, 4),
(85, '2020-04-22 07:06:57', 9, 4),
(87, '2020-04-22 07:22:38', 6, 4),
(88, '2020-04-22 09:51:50', 5, 4),
(89, '2020-04-22 09:53:15', 13, 4),
(90, '2020-04-22 13:38:07', 7, 6),
(91, '2020-04-22 13:40:45', 7, 6),
(92, '2020-04-22 13:40:52', 7, 6),
(93, '2020-04-22 13:41:22', 7, 6),
(94, '2020-04-22 13:41:39', 7, 6),
(95, '2020-04-22 13:43:34', 7, 6),
(96, '2020-04-22 13:44:19', 7, 6),
(97, '2020-04-22 13:52:46', 7, 6),
(98, '2020-04-22 13:56:04', 7, 6),
(99, '2020-04-22 13:56:32', 7, 6),
(100, '2020-04-22 13:58:06', 7, 6),
(101, '2020-04-22 14:01:41', 7, 6),
(102, '2020-04-22 14:01:52', 7, 6),
(103, '2020-04-22 14:02:23', 7, 6),
(104, '2020-04-22 14:04:49', 7, 6),
(105, '2020-04-22 14:07:20', 7, 6),
(106, '2020-04-22 14:09:29', 7, 6),
(107, '2020-04-22 14:12:28', 5, 4),
(108, '2020-04-22 14:21:57', 5, 4),
(109, '2020-04-22 15:26:00', 9, 6),
(110, '2020-04-22 15:30:12', 9, 6),
(111, '2020-04-22 15:31:35', 9, 6),
(112, '2020-04-22 15:32:21', 9, 6),
(113, '2020-04-22 15:33:15', 9, 6),
(114, '2020-04-22 15:35:04', 9, 6),
(144, '2020-04-22 16:48:38', 9, 6),
(145, '2020-04-22 16:52:51', 9, 6),
(156, '2020-04-23 03:58:17', 8, 4),
(157, '2020-04-23 04:03:34', 7, 4),
(158, '2020-04-23 04:05:21', 7, 4),
(159, '2020-04-23 04:05:47', 7, 4),
(160, '2020-04-23 04:12:39', 7, 4),
(161, '2020-04-23 04:14:35', 5, 4),
(162, '2020-04-23 04:15:39', 5, 4),
(163, '2020-04-23 04:16:24', 5, 4),
(164, '2020-04-23 04:17:06', 5, 4),
(166, '2020-04-23 10:29:02', 5, 6),
(167, '2020-04-23 10:38:29', 7, 6),
(168, '2020-04-23 10:45:50', 7, 6),
(169, '2020-04-23 10:50:15', 7, 6),
(170, '2020-04-23 10:52:25', 7, 6),
(171, '2020-04-23 10:53:11', 7, 6),
(172, '2020-04-23 10:58:20', 7, 6),
(173, '2020-04-23 10:59:32', 7, 6),
(174, '2020-04-23 11:00:30', 7, 6),
(175, '2020-04-23 11:01:43', 7, 6),
(176, '2020-04-23 11:02:27', 7, 6),
(177, '2020-04-23 11:02:58', 7, 6),
(178, '2020-04-23 11:04:35', 7, 6),
(179, '2020-04-23 11:05:43', 7, 6),
(180, '2020-04-23 11:14:41', 7, 6),
(181, '2020-04-23 11:17:27', 7, 6),
(182, '2020-04-23 11:20:06', 7, 6),
(183, '2020-04-23 11:24:50', 7, 6),
(184, '2020-04-23 11:27:56', 7, 6),
(185, '2020-04-23 11:28:51', 7, 6),
(186, '2020-04-23 11:32:34', 7, 6),
(187, '2020-04-23 11:34:23', 7, 6),
(188, '2020-04-23 11:45:15', 14, 6),
(189, '2020-04-23 11:47:37', 14, 6),
(190, '2020-04-23 11:50:02', 14, 6),
(191, '2020-04-23 11:50:42', 14, 6),
(192, '2020-04-23 11:52:04', 14, 6),
(193, '2020-04-23 11:54:31', 14, 6),
(194, '2020-04-23 11:55:50', 14, 6),
(195, '2020-04-23 11:59:44', 14, 6),
(196, '2020-04-23 12:03:16', 14, 6),
(197, '2020-04-23 12:07:06', 14, 6),
(198, '2020-04-23 12:10:12', 14, 6),
(199, '2020-04-23 12:11:10', 14, 6),
(200, '2020-04-23 12:13:14', 14, 6),
(201, '2020-04-23 12:15:11', 14, 6),
(202, '2020-04-23 12:31:05', 5, 4),
(203, '2020-04-23 12:33:27', 5, 4),
(204, '2020-04-23 12:37:47', 5, 4),
(205, '2020-04-23 12:37:52', 5, 4),
(206, '2020-04-23 12:40:17', 5, 4),
(207, '2020-04-23 12:46:30', 5, 4),
(208, '2020-04-23 12:48:31', 5, 4),
(209, '2020-04-23 12:49:26', 5, 4),
(210, '2020-04-23 12:58:25', 5, 4),
(211, '2020-04-23 13:07:48', 5, 4),
(212, '2020-04-23 13:09:01', 5, 4),
(213, '2020-04-23 13:10:26', 5, 4),
(214, '2020-04-23 13:13:44', 5, 4),
(215, '2020-04-23 13:17:03', 5, 4),
(216, '2020-04-23 13:18:17', 5, 4),
(217, '2020-04-23 13:21:19', 5, 4),
(218, '2020-04-23 13:22:31', 5, 4),
(219, '2020-04-23 13:23:51', 5, 4),
(220, '2020-04-23 13:25:24', 5, 4),
(221, '2020-04-23 13:27:06', 5, 4),
(222, '2020-04-23 13:28:35', 5, 4),
(223, '2020-04-23 13:29:30', 5, 4),
(224, '2020-04-23 13:30:32', 5, 4),
(225, '2020-04-23 13:31:23', 5, 4),
(226, '2020-04-23 13:32:09', 5, 4),
(227, '2020-04-23 13:32:27', 5, 4),
(228, '2020-04-23 13:35:56', 5, 4),
(229, '2020-04-23 13:36:44', 5, 4),
(230, '2020-04-23 13:38:26', 5, 4),
(231, '2020-04-23 16:46:43', 5, 4),
(232, '2020-04-23 16:56:44', 5, 4),
(233, '2020-04-23 17:02:06', 5, 4),
(234, '2020-04-23 17:04:22', 5, 4),
(235, '2020-04-23 17:07:24', 5, 4),
(236, '2020-04-23 17:07:59', 5, 4),
(237, '2020-04-23 17:10:03', 5, 4),
(238, '2020-04-23 17:13:20', 5, 4),
(239, '2020-04-23 17:13:41', 5, 4),
(240, '2020-04-23 17:15:48', 5, 4),
(241, '2020-04-23 17:18:00', 5, 4),
(242, '2020-04-23 17:20:51', 5, 4),
(243, '2020-04-23 17:23:11', 5, 4),
(244, '2020-04-23 17:24:30', 5, 4),
(245, '2020-04-23 17:25:16', 5, 4),
(246, '2020-04-23 17:26:10', 5, 4),
(247, '2020-04-23 17:27:28', 5, 4),
(248, '2020-04-23 17:29:23', 5, 4),
(249, '2020-04-23 17:30:19', 5, 4),
(251, '2020-04-24 09:57:02', 14, 5),
(252, '2020-04-24 10:06:38', 5, 4),
(253, '2020-04-24 11:23:58', 14, 6),
(254, '2020-04-24 11:25:03', 14, 6),
(255, '2020-04-24 11:30:26', 14, 6),
(256, '2020-04-24 11:32:42', 14, 6),
(257, '2020-04-24 11:34:30', 14, 6),
(258, '2020-04-24 11:36:09', 14, 6),
(259, '2020-04-24 11:37:58', 14, 6),
(260, '2020-04-24 11:40:26', 14, 6),
(261, '2020-04-24 11:42:08', 14, 6),
(262, '2020-04-24 11:43:40', 14, 6),
(263, '2020-04-24 11:44:33', 14, 6),
(264, '2020-04-24 11:48:28', 14, 6),
(265, '2020-04-24 11:52:01', 14, 6),
(266, '2020-04-24 11:54:46', 14, 6),
(267, '2020-04-24 13:23:38', 5, 4);

-- --------------------------------------------------------

--
-- Table structure for table `pharmacist`
--

CREATE TABLE `pharmacist` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `role` varchar(255) DEFAULT 'null',
  `user_credentials_id` int(11) NOT NULL,
  `pharmacy_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `pharmacist`
--

INSERT INTO `pharmacist` (`id`, `name`, `role`, `user_credentials_id`, `pharmacy_id`) VALUES
(1, 'admin', 'admin', 1, 1),
(2, 'Vjori Hoxha', 'admin', 1, 1),
(3, 'Arben Sinamati', 'admin', 1, 1),
(4, 'Vjori Hoxha', 'admin', 1, 1),
(5, 'Zvone Pandza', 'admin', 1, 1),
(6, 'zvone pandza', 'admin', 1, 1),
(7, 'Final Test', 'admin', 1, 1),
(8, 'Martin Zagar', 'admin', 2, 2),
(9, 'Ledion Ferati', 'admin', 1, 2),
(10, 'Lori Hoxha', 'admin', 1, 2);

-- --------------------------------------------------------

--
-- Table structure for table `pharmacy`
--

CREATE TABLE `pharmacy` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `location` varchar(255) DEFAULT NULL,
  `role` varchar(255) DEFAULT 'null'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `pharmacy`
--

INSERT INTO `pharmacy` (`id`, `name`, `location`, `role`) VALUES
(1, 'PharmaCorp', 'Zagreb', 'null'),
(2, '2nd Pharmacy', 'Split', 'pharmacy');

-- --------------------------------------------------------

--
-- Table structure for table `questions`
--

CREATE TABLE `questions` (
  `id` int(11) NOT NULL,
  `question_text` varchar(255) DEFAULT NULL,
  `question_details` varchar(255) DEFAULT NULL,
  `surv_survey_language_id` int(11) NOT NULL,
  `question_category_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `questions`
--

INSERT INTO `questions` (`id`, `question_text`, `question_details`, `surv_survey_language_id`, `question_category_id`) VALUES
(1, 'Visina', 'number', 1, 7),
(2, 'Težina', 'number', 1, 7),
(3, 'ITM', 'disabled', 1, 5),
(4, 'Izvršeno savjetovanje', 'single', 1, 1),
(5, 'Opseg struka', 'null', 1, 7),
(6, 'Opseg bokova', 'null', 1, 7),
(7, 'Omjer struk/bokovi', 'disabled', 1, 5),
(8, 'Letak poremecaj', 'single', 1, 1),
(9, 'Pušenje', 'null', 1, 4),
(10, 'Pusi', 'null', 1, 4),
(11, 'Kolicina', 'null', 1, 7),
(12, 'Broj godina nepušenja', 'null', 1, 7),
(13, 'Staž u godinama', 'null', 1, 7),
(14, 'Izvršeno savjetovanje', 'single', 1, 1),
(15, 'Letak pušenje', 'single', 1, 1),
(16, 'Konzumiranje alkohola u zadnjih godinu dana?', 'null', 1, 2),
(19, 'Sistolicki krvni tlak (mmHg)', 'null', 1, 5),
(20, 'Dijastolicki krvni tlak (mmHg)', 'null', 1, 5),
(21, 'Prevencija dijabetesa', 'null', 1, 2),
(22, 'Jeste li u posljednjih mjesec dana imali umjerenu tjelesnu aktivnost (hodanje) u trajanju 30 minuta dnevno?', 'null', 1, 2),
(23, 'Jeste li u posljednjih mjesec dana imali žustru tjelesnu aktivnost (trcanje,plivanje, vožnja bicikla) najmanje 20 minuta 3 puta tjedno?', 'null', 1, 2),
(24, 'Tjelesna aktivnost', 'null', 1, 5),
(25, 'Letak tjelesna aktivnost', 'single', 1, 1),
(26, 'Velicina tima', 'null', 1, 2),
(27, 'Vrijednost glukoze u krvi(NATAŠTE)', 'null', 1, 7),
(28, 'Vrijednost glukoze u krvi(POSTPRANDIJALNO)', 'null', 1, 7),
(29, 'Vrijednost HbA1c (mmol/L)', 'null', 1, 7),
(30, 'Vrijednost HbA1c (%)', 'null', 1, 7),
(31, 'Izvršeno mjerenje glukoze u krvi', 'single', 1, 1),
(32, 'Visina', 'null', 1, 7),
(33, 'Težina', 'null', 1, 7),
(34, 'ITM', 'disabled', 1, 5),
(35, 'Izvršeno savjetovanje za prevenciju prekomjerne TT', 'single', 1, 1),
(36, 'Letak poremecaj TT', 'single', 1, 1),
(37, 'Sistolicki krvni tlak (mm)', 'null', 1, 7),
(38, 'Dijastolicki krvni tlak (Hg)', 'null', 1, 7),
(39, 'Ukupni kolesterol (mmol/L)', 'null', 1, 7),
(40, 'HDL kolesterol (mmol/L)', 'null', 1, 7),
(41, 'LDL kolesterol (mmol/L)', 'null', 1, 7),
(42, 'Trigliceridi (mmol/L)', 'null', 1, 7),
(43, 'Kreatinin u serumu (umol/L)', 'null', 1, 7),
(44, 'eGFR (procijenjena glomerularna filtracija)', 'null', 1, 7),
(45, 'Izvršeno savjetovanje o dislipidemiji', 'single', 1, 1),
(46, 'Letak dislipidemija', 'single', 1, 1),
(47, 'Uputnica za PZZ lab - uzorkovanje lipidograma', 'single', 1, 1),
(48, 'Izvrsen pregled ocnog fundusa oftalmoskopom', 'single', 1, 1),
(49, 'Datum pregleda', 'null', 1, 3),
(50, 'Nalaz ocnog fundusa', 'null', 1, 4),
(51, 'Klinicki pregled stopala', 'null', 1, 2),
(52, 'Nalaz pregleda stopala', 'null', 1, 2),
(53, 'Izvrseno savjetovanje za secernu bolest (dijabeticko stopalo)', 'single', 1, 1),
(54, 'Visina', 'null', 1, 7),
(55, 'Letak Dijabeticko stopalo', 'single', 1, 1),
(56, 'Težina', 'null', 1, 7),
(57, 'Vrijednost albuminurije 2/ PORCIJA/UZORAK URINA (omjer albumin /kreatinin) (mg/mmol)', 'null', 1, 7),
(58, 'Vrijednost albuminurije 2/ PORCIJA/UZORAK URINA (omjer albumin /kreatinin) (ug/mg)', 'null', 1, 7),
(59, 'Amputacija udova dijabeticke geneze', 'null', 1, 2),
(60, 'Izvrseno uzorkovanje krvi za laboratorijsku analizu', 'single', 1, 1),
(61, 'Izvrseno savjetovanje o dijabetesu', 'single', 1, 1),
(62, 'Letak dijabetes', 'single', 1, 1),
(63, 'Pušenje', 'null', 1, 4),
(64, 'Pusi', 'null', 1, 4),
(65, 'Kolicina', 'null', 1, 7),
(66, 'Broj godina nepušenja', 'null', 1, 7),
(67, 'Staž u godinama', 'null', 1, 7),
(68, 'Izvrseno savjetovanje', 'single', 1, 1),
(69, 'Letak pusenje', 'single', 1, 1),
(70, 'Konzumiranje alkohola u zadnjih godinu dana?', 'null', 1, 2),
(71, 'Ucestalost konzumiranja alkohola', 'null', 1, 4),
(72, 'Najcesce koristeno pice', 'null', 1, 4),
(73, 'Tjedna kolicina alkoholnog pica', 'null', 1, 7),
(74, 'Izvrseno savjetovanje', 'single', 1, 1),
(75, 'Letak alkohol', 'single', 1, 1),
(76, 'Tjelesna aktivnost', 'null', 1, 2),
(77, 'Letak tjelesna aktivnost', 'single', 1, 1),
(78, 'Kardio vaskularni incident (dogadaj) u osobnoj anamnezi', 'null', 1, 2),
(79, 'Dokazano kronicno bubrezno zatajenje', 'null', 1, 2),
(80, 'Prerana smrt u obitelji od KV bolesti', 'null', 1, 2),
(81, 'Suradljivost u (medikamentoznoj) terapiji', 'disabled', 1, 5),
(82, 'FVC (% prediktivne vrijednosti)', 'null', 1, 7),
(83, 'FEV1 (% prediktivne vrijednosti)', 'null', 1, 7),
(84, 'FVC/FEV1', 'disabled', 1, 7),
(85, 'PEF (% prediktivne vrijednosti)', 'null', 1, 7),
(86, 'Pušenje', 'null', 1, 4),
(87, 'Pusi', 'null', 1, 4),
(88, 'Kolicina', 'null', 1, 7),
(89, 'Broj godina nepušenja', 'null', 1, 7),
(90, 'Staž u godinama', 'null', 1, 7),
(91, 'Izvrseno savjetovanje pušenje', 'single', 1, 1),
(92, 'Cijepljenje protiv gripe', 'null', 1, 4),
(93, 'Datum cijepljenja protiv gripe', 'null', 1, 3),
(94, 'Cijepljenje protiv pneumokoka', 'null', 1, 4),
(95, 'Datum cijepljenja protiv pneumokoka', 'null', 1, 3),
(96, 'Akutne egzacerbacija uz antibiotsku terapiju', 'single', 1, 1),
(97, 'Datum akutnih egzacerbacija', 'null', 1, 3),
(98, 'Hospitalizacija zbog KOPB-a', 'single', 1, 1),
(99, 'Datum hospitalizacije', 'null', 1, 3),
(100, 'Letak KOPB', 'single', 1, 1),
(101, 'Izvršena spirometrija', 'single', 1, 1),
(102, 'Datum pirometrije', 'null', 1, 3),
(103, 'Slucaj', 'null', 1, 4),
(104, 'Sistolicki krvni tlak (mmHg)/ Dijastolicki krvni tlak (mmHg)', '/', 1, 7),
(105, 'Ukupni kolesterol (mmol/L)', 'null', 1, 7),
(106, 'HDL kolesterol (mmol/L)', 'null', 1, 7),
(107, 'Pusenje', 'null', 1, 4),
(109, 'Vrijednost KV rizika', 'disabled', 1, 7),
(110, 'KV rizik', 'disabled', 1, 7),
(111, 'ITM', 'disabled', 1, 5),
(112, 'Slucaj', 'null', 1, 4),
(113, 'Visina', 'null', 1, 7),
(114, 'Težina', 'null', 1, 7),
(118, 'Opseg struka', 'null', 1, 7),
(120, 'Opseg bokova', 'null', 1, 7),
(121, 'Pusenje', 'null', 1, 4),
(122, 'Omjer struk/bokovi', 'disabled', 1, 5),
(123, 'Izvršeno savjetovanje za prevenciju prekomjerne TT', 'single', 1, 1),
(124, 'Konzumiranje alkohola u zadnjih godinu dana', 'null', 1, 2),
(125, 'Letak poremecaj TT', 'single', 1, 1),
(126, 'Sistolicki krvni tlak (mmHg)/ Dijastolicki krvni tlak (mmHg)', '/', 1, 7),
(127, 'Dokazana šecerna bolest', 'null', 1, 2),
(128, 'Vrijednost glukoze u krvi (mmol/L)', 'null', 1, 7),
(129, 'Vrijednost glukoze u krvi(NATAŠTE) (mmol/L)', 'null', 1, 7),
(130, 'Vrijednost glukoze u krvi POSTPRANDIJALNO (mmol/L)', 'null', 1, 7),
(131, 'Vrijednost glukoze u krvi(POSTPRANDIJALNO) (mmol/L)', 'null', 1, 7),
(132, 'Ukupni kolesterol (mmol/L)', 'null', 1, 7),
(133, 'Sistolicki krvni tlak (mm)', 'null', 1, 7),
(134, 'HDL kolesterol (mmol/L)', 'null', 1, 7),
(135, 'LDL kolesterol (mmol/L)', 'null', 1, 7),
(136, 'Dijastolicki krvni tlak (Hg)', 'null', 1, 7),
(137, 'Trigliceridi (mmol/L)', 'null', 1, 7),
(138, 'Izvršeno mjerenje glukoze u krvi', 'single', 1, 1),
(139, 'Hipertenzija', 'null', 1, 2),
(140, 'Izvršeno uzorkovanje krvi za laboratorijsku analizu', 'single', 1, 1),
(141, 'Ukupni kolesterol (mmol/L)', 'null', 1, 7),
(142, 'Secerna bolest', 'null', 1, 2),
(143, 'HDL kolesterol (mmol/L)', 'null', 1, 7),
(144, 'Dislipidemija', 'null', 1, 2),
(145, 'LDL kolesterol (mmol/L)', 'null', 1, 7),
(146, 'Depresija', 'null', 1, 2),
(147, 'Trigliceridi (mmol/L)', 'null', 1, 7),
(148, 'Ucestalost tjelesne aktivnosti (broj dana)', 'null', 1, 7),
(149, 'Trajanje tjelesne aktivnosti (minuta)', 'null', 1, 7),
(150, 'Kreatinin u serumu (umol/L)', 'null', 1, 7),
(151, 'eGFR (procijenjena glomerularna filtracija)', 'null', 1, 7),
(152, 'Datum popunjavanja', 'disabled', 1, 3),
(153, 'Tezina', 'null', 1, 7),
(154, 'Izvršeno savjetovanje o dislipidemiji', 'single', 1, 1),
(155, 'Visina', 'null', 1, 7),
(156, 'Broj dojenja mjesecno', 'null', 1, 7),
(157, 'Letak dislipidemija', 'single', 1, 1),
(158, 'Uputnica za PZZ lab - uzorkovanje lipidograma', 'single', 1, 1),
(159, 'Pušenje', 'null', 1, 4),
(160, 'Pusi', 'null', 1, 4),
(161, 'Dorucak', 'null', 1, 2),
(162, 'Kolicina', 'null', 1, 7),
(163, 'Napitci', 'null', 1, 2),
(164, 'Broj godina nepušenja', 'null', 1, 7),
(165, 'Staž u godinama', 'null', 1, 7),
(166, 'Tjelesna aktivnost', 'null', 1, 2),
(167, 'Izvrseno savjetovanje', 'single', 1, 1),
(168, 'Broj sati pred ekranom (po danu)', 'null', 1, 7),
(169, 'Letak pusenje', 'single', 1, 1),
(170, 'Predskolska ustanova (jaslice/vrtic)', 'null', 1, 2),
(171, 'Tjelesna aktivnost', 'null', 1, 2),
(172, 'Savjet', 'single', 1, 1),
(173, 'Letak tjelesna aktivnost', 'single', 1, 1),
(174, 'Kardiovaskularni incident (dogadaj) u osobnoj anamnezi', 'null', 1, 2),
(175, 'Dokazano kronicno bubrezno zatajenje', 'null', 1, 2),
(176, 'Prerana smrt u obitelji od KV bolesti', 'null', 1, 4),
(177, 'Napomena', 'textarea', 1, 5),
(178, 'Obiteljska anamneza', 'null', 1, 2),
(180, 'Vrijednost albuminurije 2/ PORCIJA/UZORAK URINA (omjer albumin /kreatinin) (mg/mmol)', 'null', 1, 7),
(182, 'Vrijednost albuminurije 2/ PORCIJA/UZORAK URINA (omjer albumin /kreatinin) (ug/mg)', 'null', 1, 7),
(183, 'Datum termina dolaska', 'null', 1, 3),
(184, 'Vrijeme dolaska', 'null', 1, 6),
(185, 'Broj telefona', 'null', 1, 5),
(186, 'Procjena suradljivosti', 'disabled', 1, 5),
(187, 'Lijek', 'null', 1, 4),
(188, 'Razlog uzimanja lijeka', 'null', 1, 5),
(189, 'Laboratorijski nalaz', 'null', 1, 4),
(190, 'MKB-10', 'null', 1, 5),
(191, 'PV', 'null', 1, 5),
(192, 'Nacin uzimanja', 'days_of_week', 1, 5),
(193, 'Tjedno uzimanja', 'disabled', 1, 5),
(194, 'Datum kontrole', 'null', 1, 3),
(195, 'Napomena', 'textarea', 1, 5),
(196, 'Tezina', 'null', 1, 7),
(197, 'Visina', 'null', 1, 7),
(198, 'Sistolicki krvni tlak (mm)', 'null', 1, 7),
(199, 'Dijastolicki krvni tlak (Hg)', 'null', 1, 7),
(200, 'Glukoza nataste', 'null', 1, 7),
(201, 'Dob prve promjene na kozi (broj mjeseci ako je dijete mladje od godinu dana)', 'null', 1, 7),
(202, 'Gestacijski dijabetes', 'null', 1, 2),
(203, 'Edemi', 'null', 1, 2),
(204, 'Lokalizacija', 'multiple,other', 1, 1),
(205, 'Proteini u urinu', 'null', 1, 2),
(206, 'Ucestalost promjena na kozi', 'other', 1, 2),
(207, 'Glukoza u urinu', 'null', 1, 2),
(208, 'Dermatitis i/ili alergije u obitelji', 'null', 1, 2),
(209, 'Ucinjena alergoloska obrada', 'null', 1, 2),
(210, 'Alergija potvrdena', 'null', 1, 2),
(211, 'Lijecenje (oznaciti/upisati 1 ili vise)', 'multiple,other', 1, 1),
(212, 'MKB dijagnoze koznih promjena', 'null', 1, 5),
(213, 'Provedeno savjetovanje', 'null', 1, 2),
(214, 'Koje savjetovanje je obavljeno', 'multiple,other', 1, 1),
(215, 'Napomena', 'textarea', 1, 5),
(221, 'Another question', 'novi', 1, 3),
(227, 'Test question text', 'novi', 1, 2),
(228, 'Test pitanje', 'novi', 1, 2),
(232, 'Test question text', 'novi', 1, 2),
(233, 'Test question text', 'novi', 1, 2),
(242, 'This is a test', 'novi', 1, 5),
(243, 'This is a test', 'novi', 1, 5),
(244, 'sdasdadsaads', 'novi', 1, 13),
(245, 'saddasasdd', 'novi', 1, 5),
(246, 'dsadsa s asd as das', 'novi', 1, 5),
(247, 'ads', 'novi', 1, 5),
(248, 'Test question text', 'novi', 1, 2),
(249, 'Testno pitanje', 'novi', 1, 2),
(250, 'Test test', 'novi', 1, 2),
(251, 'test question text', 'novi', 1, 2),
(252, 'Da', 'novi', 1, 2),
(253, 'Test question text', 'novi', 1, 2),
(254, 'Tezina', 'novi', 1, 7),
(255, 'Visina', 'novi', 1, 7),
(256, 'Debel', 'novi', 1, 4),
(257, 'Visina', 'novi', 1, 7),
(258, 'Tezina', 'novi', 1, 7),
(259, 'ITM', 'novi', 1, 12),
(260, 'Pusenje', 'novi', 1, 4),
(261, 'Pusi', 'novi', 1, 4),
(264, 'Letak pusenje', 'novi', 1, 1),
(265, 'Letak prestanak pusenja', 'novi', 1, 1),
(266, 'Test pitanje', 'novi', 1, 2),
(273, 'Vrijeme nepusenja', 'novi', 1, 4),
(278, 'Updated question text', 'novi', 1, 2),
(279, 'Question that will be updated', 'novi', 1, 4),
(280, 'Test question text', 'novi', 1, 7),
(281, 'Sa odgovorima', 'novi', 1, 2),
(282, 'What is up?', 'novi', 1, 5),
(283, 'Checkbox + tekst', 'novi', 1, 9),
(284, 'more checkbox', 'novi', 1, 8),
(285, 'Dateee', 'novi', 1, 3),
(287, 'Dropdown I gues', 'novi', 1, 4),
(288, 'Testing radio', 'novi', 1, 2),
(289, 'asdad', 'novi', 1, 6),
(290, 'Ucestalost konzumiranja alkohola', 'novi', 1, 4),
(291, 'Najcesce koristeno pice', 'novi', 1, 4),
(292, 'Tjedna kolicina alkoholnog pica', 'novi', 1, 7),
(293, 'Izvrseno savjetovanje', 'novi', 1, 1),
(294, 'Letak alkohol', 'novi', 1, 1),
(295, 'ITM', 'novi', 1, 12),
(296, 'Opseg struka', 'novi', 1, 7),
(297, 'Opseg bokova', 'novi', 1, 7),
(298, 'Omjer struk/bokovi', 'novi', 1, 12);

-- --------------------------------------------------------

--
-- Table structure for table `question_answers`
--

CREATE TABLE `question_answers` (
  `id` int(11) NOT NULL,
  `text` varchar(255) DEFAULT NULL,
  `option_value` varchar(255) DEFAULT NULL,
  `questions_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `question_answers`
--

INSERT INTO `question_answers` (`id`, `text`, `option_value`, `questions_id`) VALUES
(9, 'Pusac', 'answer_1', 9),
(10, 'Bivsi Pusac', 'answer_2', 9),
(11, 'Nepusac', 'answer_3', 9),
(12, 'Cigarete', 'answer_1', 10),
(13, 'Lula', 'answer_2', 10),
(14, 'Cigare', 'answer_3', 10),
(15, 'Da', 'answer_1', 16),
(16, 'Ne', 'answer_2', 16),
(17, 'Da', 'answer_1', 21),
(18, 'Ne', 'answer_2', 21),
(19, 'Da', 'answer_1', 22),
(20, 'Ne', 'answer_2', 22),
(21, 'Nije odabrano', 'answer_3', 22),
(22, 'Da', 'answer_1', 23),
(23, 'Ne', 'answer_2', 23),
(24, 'Nije odabrano', 'answer_3', 23),
(25, 'Mali (1275-1700)', 'answer_1', 26),
(26, 'Veliki (1700-2125)', 'answer_2', 26),
(27, 'Bez podataka', 'answer_1', 50),
(28, 'Bez znakova dijabeticke retinopatije', 'answer_2', 50),
(29, 'Dijabeticka retinopatija – neproliferativna', 'answer_3', 50),
(30, 'Dijabeticka retinopatija - proliferativna', 'answer_4', 50),
(31, 'Da', 'answer_1', 51),
(32, 'Ne', 'answer_2', 51),
(33, 'Znakovi dijabetickog stopala', 'answer_1', 52),
(34, 'Nema znakova dijabetickog stopala', 'answer_2', 52),
(35, 'Da', 'answer_1', 59),
(36, 'Ne', 'answer_2', 59),
(37, 'Pusac', 'answer_1', 63),
(38, 'Bivsi pusac', 'answer_2', 63),
(39, 'Nepusac', 'answer_3', 63),
(40, 'Cigarete', 'answer_1', 64),
(41, 'Lula', 'answer_2', 64),
(42, 'Cigare', 'answer_3', 64),
(43, 'Da', 'answer_1', 70),
(44, 'Ne', 'answer_2', 70),
(45, 'Prigodno', 'answer_1', 71),
(46, 'Vikendom', 'answer_2', 71),
(47, 'Vise puta tjedno', 'answer_3', 71),
(48, 'Svakodnevno', 'answer_4', 71),
(49, 'Vino', 'answer_1', 72),
(50, 'Pivo', 'answer_2', 72),
(51, 'Zestoka pica', 'answer_3', 72),
(52, 'Zadovoljavajuca', 'answer_1', 76),
(53, 'Nezadovoljavajuca', 'answer_2', 76),
(54, 'Da', 'answer_1', 78),
(55, 'Ne', 'answer_2', 78),
(56, 'Da', 'answer_1', 79),
(57, 'Ne', 'answer_2', 79),
(58, 'Da', 'answer_1', 80),
(59, 'Ne', 'answer_2', 80),
(60, 'Da', 'answer_1', 127),
(61, 'Ne', 'answer_2', 127),
(62, 'Pusac', 'answer_1', 159),
(63, 'Bivsi pusac', 'answer_2', 159),
(64, 'Nepusac', 'answer_3', 159),
(65, 'Cigarete', 'answer_1', 160),
(66, 'Lula', 'answer_2', 160),
(67, 'Cigare', 'answer_3', 160),
(68, 'Zadovoljavajuca', 'answer_1', 171),
(69, 'Nezadovoljavajuca', 'answer_2', 171),
(70, 'Da', 'answer_1', 174),
(71, 'Ne', 'answer_2', 174),
(72, 'Da', 'answer_1', 175),
(73, 'Ne', 'answer_2', 175),
(74, 'Da', 'answer_1', 176),
(75, 'Ne', 'answer_2', 176),
(76, 'Da', 'answer_1', 178),
(77, 'Ne', 'answer_2', 178),
(78, 'Pusac', 'answer_1', 86),
(79, 'Bivsi pusac', 'answer_2', 86),
(80, 'Nepusac', 'answer_3', 86),
(81, 'Cigarete', 'answer_1', 87),
(82, 'Lula', 'answer_2', 87),
(83, 'Cigare', 'answer_3', 87),
(84, 'Da', 'answer_1', 92),
(85, 'Ne', 'answer_2', 92),
(86, 'Odbio', 'answer_3', 92),
(87, 'Da', 'answer_1', 94),
(88, 'Ne', 'answer_2', 94),
(89, 'Odbio', 'answer_3', 94),
(90, 'Da', 'answer_1', 107),
(91, 'Ne', 'answer_2', 107),
(92, 'Paracetamol', 'answer_1', 187),
(93, 'Sumamed', 'answer_2', 187),
(94, 'Neofen', 'answer_3', 187),
(95, 'Ne', 'answer_1', 121),
(96, 'Da', 'answer_2', 121),
(97, 'Da', 'answer_1', 124),
(98, 'Ne', 'answer_2', 124),
(99, 'Da', 'answer_1', 139),
(100, 'Ne', 'answer_2', 139),
(101, 'Da', 'answer_1', 142),
(102, 'Ne', 'answer_2', 142),
(103, 'Da', 'answer_1', 144),
(104, 'Ne', 'answer_2', 144),
(105, 'Da', 'answer_1', 146),
(106, 'Ne', 'answer_2', 146),
(107, 'Da', 'answer_1', 161),
(108, 'Ne', 'answer_2', 161),
(109, 'Uglavnom voda', 'answer_1', 163),
(110, 'Uglavnom ostali zasladjeni napitci', 'answer_2', 163),
(111, 'Da', 'answer_1', 166),
(112, 'Ne', 'answer_2', 166),
(113, 'Da', 'answer_1', 170),
(114, 'Ne', 'answer_2', 170),
(115, 'Lice', 'answer_1', 204),
(116, 'Vrat', 'answer_2', 204),
(117, 'Trup', 'answer_3', 204),
(118, 'Udovi', 'answer_4', 204),
(119, 'Manje od 1x godisnje', 'answer_1', 206),
(120, '1x godisnje', 'answer_2', 206),
(121, '2-4x godisnje', 'answer_3', 206),
(122, '5-6x godisnje', 'answer_4', 206),
(123, 'Vise od 6x godisnje', 'answer_5', 206),
(124, 'Da', 'answer_1', 208),
(125, 'Ne', 'answer_2', 208),
(126, 'Da', 'answer_1', 209),
(127, 'Ne', 'answer_2', 209),
(128, 'Da', 'answer_1', 210),
(129, 'Ne', 'answer_2', 210),
(130, 'Neutralni pripravci', 'answer_1', 211),
(131, 'Kortikosteroidni pripravci', 'answer_2', 211),
(132, 'Antihistaminici', 'answer_3', 211),
(133, 'Antibiotici', 'answer_4', 211),
(134, 'Antimikotici', 'answer_5', 211),
(135, 'Da', 'answer_1', 213),
(136, 'Ne', 'answer_2', 213),
(137, 'O prehrani', 'answer_1', 214),
(138, 'O njezi i higijeni', 'answer_2', 214),
(139, 'O stetnim utjecajima', 'answer_3', 214),
(140, 'O lijecenju', 'answer_4', 214),
(141, 'Da', 'answer_1', 202),
(142, 'Ne', 'answer_2', 202),
(143, 'Da', 'answer_1', 203),
(144, 'Ne', 'answer_2', 203),
(145, 'Da', 'answer_1', 205),
(146, 'Ne', 'answer_2', 205),
(147, 'Pozitivno', 'answer_1', 207),
(148, 'Negativno', 'answer_2', 207),
(149, 'test', 'option_value_novi', 228),
(150, 'test', 'option_value_novi', 228),
(151, 'test', 'option_value_novi', 228),
(152, 'Da', 'option_value_novi', 249),
(153, 'Da', 'option_value_novi', 250),
(154, 'Da', 'option_value_novi', 251),
(155, 'DA', 'option_value_novi', 252),
(156, 'Da', 'option_value_novi', 253),
(157, 'Ne', 'option_value_novi', 253),
(158, 'Da', 'option_value_novi', 256),
(159, 'Ne', 'option_value_novi', 256),
(160, 'Josip', 'option_value_novi', 256),
(161, 'Pusac', 'option_value_novi', 260),
(162, 'Nepusac', 'option_value_novi', 260),
(163, 'Bivsi pusac', 'option_value_novi', 260),
(164, 'Cigare', 'option_value_novi', 261),
(165, 'Cigarete', 'option_value_novi', 261),
(166, 'Lula', 'option_value_novi', 261),
(167, 'Da', 'option_value_novi', 266),
(168, 'Ne', 'option_value_novi', 266),
(169, '1', 'option_value_novi', 273),
(170, '2', 'option_value_novi', 273),
(177, 'Da', 'option_value_novi', 278),
(178, 'Ne', 'option_value_novi', 278),
(179, 'Prvi', 'option_value_novi', 279),
(180, 'Update', 'option_value_novi', 279),
(181, 'Treci', 'option_value_novi', 279),
(182, 'Updated', 'option_value_novi', 281),
(183, 'Ne', 'option_value_novi', 281),
(184, '13221', 'option_value_novi', 283),
(185, '213', 'option_value_novi', 283),
(186, 'dsad', 'option_value_novi', 283),
(187, '1', 'option_value_novi', 284),
(188, '312', 'option_value_novi', 284),
(189, '12', 'option_value_novi', 284),
(190, '41d', 'option_value_novi', 284),
(191, 'edited nswer', 'option_value_novi', 287),
(192, '13233', 'option_value_novi', 287),
(193, '3111', 'option_value_novi', 287),
(194, '1321', 'option_value_novi', 288),
(195, '321', 'option_value_novi', 288),
(196, '333', 'option_value_novi', 288),
(197, 'Prigodno', 'option_value_novi', 290),
(198, 'Vikendom', 'option_value_novi', 290),
(199, 'Više puta tjedno', 'option_value_novi', 290),
(200, 'Svakodnevno', 'option_value_novi', 290),
(201, 'Vino', 'option_value_novi', 291),
(202, 'Pivo', 'option_value_novi', 291),
(203, 'Žestoka pica', 'option_value_novi', 291);

-- --------------------------------------------------------

--
-- Table structure for table `question_category`
--

CREATE TABLE `question_category` (
  `id` int(11) NOT NULL,
  `category_name` varchar(255) NOT NULL,
  `detail` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `question_category`
--

INSERT INTO `question_category` (`id`, `category_name`, `detail`) VALUES
(1, 'Checkbox', NULL),
(2, 'Radiobutton', NULL),
(3, 'Datum', NULL),
(4, 'Padajući izbornik', NULL),
(5, 'Tekst', NULL),
(6, 'Vrijeme', NULL),
(7, 'Broj', NULL),
(8, 'Više checkboxova', NULL),
(9, 'Checkbox + tekst', NULL),
(10, 'Radio + tekst', NULL),
(12, 'Onemogućen tekst', NULL),
(13, 'Tekst/Tekst', NULL),
(14, 'Polje za upis više teksta', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `surv_panel_labels_questions`
--

CREATE TABLE `surv_panel_labels_questions` (
  `id` int(11) NOT NULL,
  `label_title` varchar(255) DEFAULT NULL,
  `start_order` int(11) DEFAULT NULL,
  `end_order` int(11) DEFAULT NULL,
  `surv_survey_panels_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `surv_panel_labels_questions`
--

INSERT INTO `surv_panel_labels_questions` (`id`, `label_title`, `start_order`, `end_order`, `surv_survey_panels_id`) VALUES
(1, 'Tjelesne mjere', 1, 8, 1),
(2, 'Pušenje', 1, 7, 1),
(3, 'Alkohol', 1, 3, 1),
(4, 'Krvni pritisak', 1, 2, 1),
(5, 'Prevencija dijabetesa', 1, 1, 1),
(6, 'Tjelesna aktivnost', 1, 4, 1),
(7, 'Tim', 1, 1, 1),
(15, 'Krvne mjere', 1, 5, 2),
(16, 'Tjelesne mjere', 1, 5, 2),
(17, 'Krvni pritisak', 1, 2, 2),
(18, 'Lipidogram i vrijednost kreatinina', 1, 9, 2),
(19, 'Ocni pregled', 1, 3, 2),
(20, 'Pregled stopala', 1, 4, 2),
(21, 'Vrijednosti albuminurija', 1, 2, 2),
(22, 'Dijabetes', 1, 4, 2),
(23, 'Pusenje', 1, 7, 2),
(24, 'Alkohol', 1, 6, 2),
(25, 'Tjelesna aktivnost', 1, 2, 2),
(26, 'Nasljedne i kronicne bolesti', 1, 3, 2),
(27, 'Suradljivost', 1, 1, 2),
(28, 'Tjelesne mjere', 1, 8, 3),
(29, 'Krvne mjere', 1, 7, 3),
(30, 'Lipidogram i vrijednost kreatinina', 1, 9, 3),
(31, 'Pusenje', 1, 7, 3),
(32, 'Tjelesna aktivnost', 1, 2, 3),
(33, 'Nasljedne i kronicne bolesti', 1, 4, 3),
(34, 'Vrijednosti albuminurija', 1, 2, 3),
(35, 'Disni sustav', 1, 4, 4),
(36, 'Pusenje', 1, 6, 4),
(37, 'Cijepljenje', 1, 4, 4),
(38, 'Egzacerbacija', 1, 2, 4),
(40, 'Hospitalizacija', 1, 3, 4),
(41, 'Spirometrija', 1, 2, 4),
(42, 'Slucaj', 1, 1, 5),
(43, 'Vrijednost krvnog tlaka', 1, 2, 5),
(44, 'Lipidogram i vrijednost kreatinina', 1, 2, 5),
(45, 'Prevencija pusenja', 1, 1, 5),
(46, 'KV rizik', 1, 2, 5),
(50, 'Antikoagulantni nalaz', 1, 7, 7),
(51, 'Slucaj', 1, 1, 8),
(52, 'Tjelesna mjerenja', 1, 6, 8),
(53, 'Pusenje', 1, 1, 8),
(54, 'Konzumiranje alkohola', 1, 1, 8),
(55, 'Vrijednost krvnog tlaka', 1, 1, 8),
(56, 'Glukoza u krvi', 1, 2, 8),
(57, 'Lipidogram i vrijednost kreatinina', 1, 4, 8),
(58, 'Komorbiditet', 1, 4, 8),
(59, 'Tjelesna aktivnost', 1, 2, 8),
(60, 'Panel rasta i uhranjenosti', 1, 11, 9),
(61, 'Promjene na kozi', 1, 3, 10),
(62, 'Alergije', 1, 3, 10),
(63, 'Lijecenje', 1, 2, 10),
(64, 'Promjene na kozi', 1, 3, 10),
(65, 'Tjelesne mjere', 1, 2, 11),
(66, 'Krvni tlak', 1, 2, 11),
(68, 'Secerne pretrage', 1, 2, 11),
(69, 'Ostalo', 1, 3, 11);

-- --------------------------------------------------------

--
-- Table structure for table `surv_panel_questions`
--

CREATE TABLE `surv_panel_questions` (
  `id` int(11) NOT NULL,
  `question_order` int(11) DEFAULT NULL,
  `surv_survey_panels_id` int(11) NOT NULL,
  `questions_id` int(11) NOT NULL,
  `surv_panel_labels_questions_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `surv_panel_questions`
--

INSERT INTO `surv_panel_questions` (`id`, `question_order`, `surv_survey_panels_id`, `questions_id`, `surv_panel_labels_questions_id`) VALUES
(1, 1, 1, 1, 1),
(2, 2, 1, 2, 1),
(3, 3, 1, 3, 1),
(4, 4, 1, 4, 1),
(5, 5, 1, 5, 1),
(6, 6, 1, 6, 1),
(7, 7, 1, 7, 1),
(8, 8, 1, 8, 1),
(9, 1, 1, 9, 2),
(10, 2, 1, 10, 2),
(11, 3, 1, 11, 2),
(12, 4, 1, 12, 2),
(13, 5, 1, 13, 2),
(14, 6, 1, 14, 2),
(15, 7, 1, 15, 2),
(16, 1, 1, 16, 3),
(19, 1, 1, 19, 4),
(20, 2, 1, 20, 4),
(21, 1, 1, 21, 5),
(22, 1, 1, 22, 6),
(23, 2, 1, 23, 6),
(24, 3, 1, 24, 6),
(25, 4, 1, 25, 6),
(26, 1, 1, 26, 7),
(27, 1, 2, 27, 15),
(28, 2, 2, 28, 15),
(29, 3, 2, 29, 15),
(30, 4, 2, 30, 15),
(31, 5, 2, 31, 15),
(32, 1, 2, 32, 16),
(33, 2, 2, 33, 16),
(34, 3, 2, 34, 16),
(35, 4, 2, 35, 16),
(36, 5, 2, 36, 16),
(37, 1, 2, 37, 17),
(38, 2, 2, 38, 17),
(39, 1, 2, 39, 18),
(40, 2, 2, 40, 18),
(41, 3, 2, 41, 18),
(42, 4, 2, 42, 18),
(43, 5, 2, 43, 18),
(44, 6, 2, 44, 18),
(45, 7, 2, 45, 18),
(46, 8, 2, 46, 18),
(47, 9, 2, 47, 18),
(48, 1, 2, 48, 19),
(49, 2, 2, 49, 19),
(50, 3, 2, 50, 19),
(51, 1, 2, 51, 20),
(52, 2, 2, 52, 20),
(53, 3, 2, 53, 20),
(54, 1, 3, 54, 28),
(55, 4, 2, 55, 20),
(56, 2, 3, 56, 28),
(57, 1, 2, 57, 21),
(58, 2, 2, 58, 21),
(59, 1, 2, 59, 22),
(60, 2, 2, 60, 22),
(61, 3, 2, 61, 22),
(62, 4, 2, 62, 22),
(63, 1, 2, 63, 23),
(64, 2, 2, 64, 23),
(65, 3, 2, 65, 23),
(66, 4, 2, 66, 23),
(67, 5, 2, 67, 23),
(68, 6, 2, 68, 23),
(69, 7, 2, 69, 23),
(70, 1, 2, 70, 24),
(71, 2, 2, 71, 24),
(72, 3, 2, 72, 24),
(73, 4, 2, 73, 24),
(74, 5, 2, 74, 24),
(75, 6, 2, 75, 24),
(76, 1, 2, 76, 25),
(77, 2, 2, 77, 25),
(78, 1, 2, 78, 26),
(79, 2, 2, 79, 26),
(80, 3, 2, 80, 26),
(81, 1, 2, 81, 27),
(82, 1, 4, 82, 35),
(83, 2, 4, 83, 35),
(84, 3, 4, 84, 35),
(85, 4, 4, 85, 35),
(86, 1, 4, 86, 36),
(87, 2, 4, 87, 36),
(88, 3, 4, 88, 36),
(89, 4, 4, 89, 36),
(90, 5, 4, 90, 36),
(91, 6, 4, 91, 36),
(92, 1, 4, 92, 37),
(93, 2, 4, 93, 37),
(94, 3, 4, 94, 37),
(95, 4, 4, 95, 37),
(96, 1, 4, 96, 38),
(97, 2, 4, 97, 38),
(98, 1, 4, 98, 40),
(99, 2, 4, 99, 40),
(100, 3, 4, 100, 40),
(101, 1, 4, 101, 41),
(102, 2, 4, 102, 41),
(103, 1, 5, 103, 42),
(104, 1, 5, 104, 43),
(105, 1, 5, 105, 44),
(106, 2, 5, 106, 44),
(107, 1, 5, 107, 45),
(109, 1, 5, 109, 46),
(110, 2, 5, 110, 46),
(111, 3, 3, 111, 28),
(112, 1, 8, 112, 51),
(113, 1, 8, 113, 52),
(114, 2, 8, 114, 52),
(118, 4, 3, 118, 28),
(120, 5, 3, 120, 28),
(121, 1, 8, 121, 53),
(122, 6, 3, 122, 28),
(123, 7, 3, 123, 28),
(124, 1, 8, 124, 54),
(125, 8, 3, 125, 28),
(126, 1, 8, 126, 55),
(127, 1, 3, 127, 29),
(128, 1, 8, 128, 56),
(129, 2, 3, 129, 29),
(130, 2, 8, 130, 56),
(131, 3, 3, 131, 29),
(132, 1, 8, 132, 57),
(133, 4, 3, 133, 29),
(134, 2, 8, 134, 57),
(135, 3, 8, 135, 57),
(136, 5, 3, 136, 29),
(137, 4, 8, 137, 57),
(138, 6, 3, 138, 29),
(139, 1, 8, 139, 58),
(140, 7, 3, 140, 29),
(141, 1, 3, 141, 30),
(142, 2, 8, 142, 58),
(143, 2, 3, 143, 30),
(144, 3, 8, 144, 58),
(145, 3, 3, 145, 30),
(146, 4, 8, 146, 58),
(147, 4, 3, 147, 30),
(148, 1, 8, 148, 59),
(149, 2, 8, 149, 59),
(150, 5, 3, 150, 30),
(151, 6, 3, 151, 30),
(152, 1, 9, 152, 60),
(153, 2, 9, 153, 60),
(154, 7, 3, 154, 30),
(155, 3, 9, 155, 60),
(156, 4, 9, 156, 60),
(157, 8, 3, 157, 30),
(158, 9, 3, 158, 30),
(159, 1, 3, 159, 31),
(160, 2, 3, 160, 31),
(161, 5, 9, 161, 60),
(162, 3, 3, 162, 31),
(163, 6, 9, 163, 60),
(164, 4, 3, 164, 31),
(165, 5, 3, 165, 31),
(166, 7, 9, 166, 60),
(167, 6, 3, 167, 31),
(168, 8, 9, 168, 60),
(169, 7, 3, 169, 31),
(170, 9, 9, 170, 60),
(171, 1, 3, 171, 32),
(172, 10, 9, 172, 60),
(173, 2, 3, 173, 32),
(174, 1, 3, 174, 33),
(175, 2, 3, 175, 33),
(176, 3, 3, 176, 33),
(177, 11, 9, 177, 60),
(178, 4, 3, 178, 33),
(180, 1, 3, 180, 34),
(182, 2, 3, 182, 34),
(189, 1, 7, 189, 50),
(190, 2, 7, 190, 50),
(191, 3, 7, 191, 50),
(192, 4, 7, 192, 50),
(193, 5, 7, 193, 50),
(194, 6, 7, 194, 50),
(195, 7, 7, 195, 50),
(196, 1, 11, 196, 65),
(197, 2, 11, 197, 65),
(198, 1, 11, 198, 66),
(199, 2, 11, 199, 66),
(200, 1, 11, 200, 68),
(201, 1, 10, 201, 61),
(202, 2, 11, 202, 68),
(203, 1, 11, 203, 69),
(204, 2, 10, 204, 61),
(205, 2, 11, 205, 69),
(206, 3, 10, 206, 61),
(207, 3, 11, 207, 69),
(208, 1, 10, 208, 62),
(209, 2, 10, 209, 62),
(210, 3, 10, 210, 62),
(211, 1, 10, 211, 63),
(212, 2, 10, 212, 63),
(213, 1, 10, 213, 64),
(214, 2, 10, 214, 64),
(215, 3, 10, 215, 64),
(290, 1, 1, 290, 3),
(291, 1, 1, 291, 3),
(292, 1, 1, 292, 3),
(293, 1, 1, 293, 3),
(294, 1, 1, 294, 3),
(295, 1, 8, 295, 52),
(296, 1, 8, 296, 52),
(297, 1, 8, 297, 52),
(298, 1, 8, 298, 52);

-- --------------------------------------------------------

--
-- Table structure for table `surv_survey`
--

CREATE TABLE `surv_survey` (
  `id` int(11) NOT NULL,
  `date_created` date NOT NULL,
  `hash` varchar(255) DEFAULT 'null'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `surv_survey`
--

INSERT INTO `surv_survey` (`id`, `date_created`, `hash`) VALUES
(1, '2020-04-11', 'hash');

-- --------------------------------------------------------

--
-- Table structure for table `surv_survey_has_surv_survey_language`
--

CREATE TABLE `surv_survey_has_surv_survey_language` (
  `surv_survey_id` int(11) NOT NULL,
  `surv_survey_language_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `surv_survey_has_surv_survey_language`
--

INSERT INTO `surv_survey_has_surv_survey_language` (`surv_survey_id`, `surv_survey_language_id`) VALUES
(1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `surv_survey_language`
--

CREATE TABLE `surv_survey_language` (
  `id` int(11) NOT NULL,
  `language_code` varchar(2) NOT NULL,
  `language_name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `surv_survey_language`
--

INSERT INTO `surv_survey_language` (`id`, `language_code`, `language_name`) VALUES
(1, 'HR', 'Hrvatski'),
(2, 'EN', 'Englsh');

-- --------------------------------------------------------

--
-- Table structure for table `surv_survey_panels`
--

CREATE TABLE `surv_survey_panels` (
  `id` int(11) NOT NULL,
  `panel_name` varchar(255) NOT NULL,
  `surv_survey_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `surv_survey_panels`
--

INSERT INTO `surv_survey_panels` (`id`, `panel_name`, `surv_survey_id`) VALUES
(1, '(P-1) Preventivni Panel', 1),
(2, '(P-3) Panel Dijabetes', 1),
(3, '(P-3.2) Panel Hipertenzija', 1),
(4, '(P-3.3) Panel KOPB', 1),
(5, '(P-4) Panel KVRP', 1),
(7, '(P-6) Panel antikoagulantne terapije', 1),
(8, '(P-7) Panel ITM', 1),
(9, '(P-8) Panel rasta i uhranjenosti', 1),
(10, '(P-9) Panel dermatitis u djece', 1),
(11, '(P-10) Panel Trudnice', 1);

-- --------------------------------------------------------

--
-- Table structure for table `user_credentials`
--

CREATE TABLE `user_credentials` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` mediumtext NOT NULL,
  `email` varchar(255) NOT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `user_credentials`
--

INSERT INTO `user_credentials` (`id`, `username`, `password`, `email`, `user_id`) VALUES
(1, 'admin', 'admin', 'test@gmail.com', 1),
(2, 'vjorihoxha', 'testTest', 'hoxhavjori@gmail.com', 2),
(3, 'asinamati', 'b20873757abf180dba30ee4e9fcd2a873b15f09180bdfd26519d17f48c5546497bbfa1b30029ebe6aca6e4cbd35c734d9e30f104b85927f3beab3c48de724d5d', 'as@gmail.com', 3),
(4, 'vhoxha', 'b20873757abf180dba30ee4e9fcd2a873b15f09180bdfd26519d17f48c5546497bbfa1b30029ebe6aca6e4cbd35c734d9e30f104b85927f3beab3c48de724d5d', 'vxh5681@g.rit.edu', 4),
(5, 'zvone', '43166150549e37e1790000f7eeeec5ef4aa552263cc6e1dc7977b7579958dcd41427931a16ab30365ca9aaee6242d363415c17c2661327ad360630d3cf919569', 'zvone.pandza@gmail.com', 5),
(6, 'test', '125d6d03b32c84d492747f79cf0bf6e179d287f341384eb5d6d3197525ad6be8e6df0116032935698f99a09e265073d1d6c32c274591bf1d0a20ad67cba921bc', 'zvone.pandzaa@gmail.com', 6),
(7, 'fintest', 'b20873757abf180dba30ee4e9fcd2a873b15f09180bdfd26519d17f48c5546497bbfa1b30029ebe6aca6e4cbd35c734d9e30f104b85927f3beab3c48de724d5d', 'finatest@gmail.com', 7),
(8, 'martin', 'b20873757abf180dba30ee4e9fcd2a873b15f09180bdfd26519d17f48c5546497bbfa1b30029ebe6aca6e4cbd35c734d9e30f104b85927f3beab3c48de724d5d', 'mxz@gmail.com', 8),
(9, 'ledion', 'b20873757abf180dba30ee4e9fcd2a873b15f09180bdfd26519d17f48c5546497bbfa1b30029ebe6aca6e4cbd35c734d9e30f104b85927f3beab3c48de724d5d', 'lxf@g.rit.edu', 9),
(10, 'lori', 'b20873757abf180dba30ee4e9fcd2a873b15f09180bdfd26519d17f48c5546497bbfa1b30029ebe6aca6e4cbd35c734d9e30f104b85927f3beab3c48de724d5d', 'lxh@gmail.com', 10);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `patient`
--
ALTER TABLE `patient`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `patient_answers`
--
ALTER TABLE `patient_answers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `patient_record_history`
--
ALTER TABLE `patient_record_history`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_patient_record_history_patient_idx` (`patient_id`),
  ADD KEY `fk_patient_record_history_pharmacist1_idx` (`pharmacist_id`);

--
-- Indexes for table `pharmacist`
--
ALTER TABLE `pharmacist`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_pharmacist_user_credentials1_idx` (`user_credentials_id`),
  ADD KEY `fk_pharmacy_id_idx` (`pharmacy_id`);

--
-- Indexes for table `pharmacy`
--
ALTER TABLE `pharmacy`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `questions`
--
ALTER TABLE `questions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_questions_surv_survey_language1_idx` (`surv_survey_language_id`),
  ADD KEY `fk_questions_question_category1_idx` (`question_category_id`);

--
-- Indexes for table `question_answers`
--
ALTER TABLE `question_answers`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_question_answers_questions1_idx` (`questions_id`);

--
-- Indexes for table `question_category`
--
ALTER TABLE `question_category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `surv_panel_labels_questions`
--
ALTER TABLE `surv_panel_labels_questions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_surv_panel_labels_questions_surv_survey_panels1_idx` (`surv_survey_panels_id`);

--
-- Indexes for table `surv_panel_questions`
--
ALTER TABLE `surv_panel_questions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_surv_panel_questions_surv_survey_panels1_idx` (`surv_survey_panels_id`),
  ADD KEY `fk_surv_panel_questions_questions1_idx` (`questions_id`),
  ADD KEY `surv_panel_labels_questions_id` (`surv_panel_labels_questions_id`);

--
-- Indexes for table `surv_survey`
--
ALTER TABLE `surv_survey`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `surv_survey_has_surv_survey_language`
--
ALTER TABLE `surv_survey_has_surv_survey_language`
  ADD PRIMARY KEY (`surv_survey_id`,`surv_survey_language_id`),
  ADD KEY `fk_surv_survey_has_surv_survey_language_surv_survey_languag_idx` (`surv_survey_language_id`),
  ADD KEY `fk_surv_survey_has_surv_survey_language_surv_survey1_idx` (`surv_survey_id`);

--
-- Indexes for table `surv_survey_language`
--
ALTER TABLE `surv_survey_language`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `surv_survey_panels`
--
ALTER TABLE `surv_survey_panels`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_surv_survey_panels_surv_survey1_idx` (`surv_survey_id`);

--
-- Indexes for table `user_credentials`
--
ALTER TABLE `user_credentials`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `patient`
--
ALTER TABLE `patient`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `patient_answers`
--
ALTER TABLE `patient_answers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=692;

--
-- AUTO_INCREMENT for table `patient_record_history`
--
ALTER TABLE `patient_record_history`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=268;

--
-- AUTO_INCREMENT for table `pharmacist`
--
ALTER TABLE `pharmacist`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `pharmacy`
--
ALTER TABLE `pharmacy`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `questions`
--
ALTER TABLE `questions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=299;

--
-- AUTO_INCREMENT for table `question_answers`
--
ALTER TABLE `question_answers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=204;

--
-- AUTO_INCREMENT for table `question_category`
--
ALTER TABLE `question_category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `surv_panel_labels_questions`
--
ALTER TABLE `surv_panel_labels_questions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=87;

--
-- AUTO_INCREMENT for table `surv_panel_questions`
--
ALTER TABLE `surv_panel_questions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=299;

--
-- AUTO_INCREMENT for table `surv_survey`
--
ALTER TABLE `surv_survey`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `surv_survey_language`
--
ALTER TABLE `surv_survey_language`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `surv_survey_panels`
--
ALTER TABLE `surv_survey_panels`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT for table `user_credentials`
--
ALTER TABLE `user_credentials`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `patient_record_history`
--
ALTER TABLE `patient_record_history`
  ADD CONSTRAINT `fk_patient_record_history_patient` FOREIGN KEY (`patient_id`) REFERENCES `patient` (`id`),
  ADD CONSTRAINT `fk_patient_record_history_pharmacist1` FOREIGN KEY (`pharmacist_id`) REFERENCES `pharmacist` (`id`);

--
-- Constraints for table `pharmacist`
--
ALTER TABLE `pharmacist`
  ADD CONSTRAINT `fk_pharmacist_user_credentials1` FOREIGN KEY (`user_credentials_id`) REFERENCES `user_credentials` (`id`),
  ADD CONSTRAINT `fk_pharmacy_id` FOREIGN KEY (`pharmacy_id`) REFERENCES `pharmacy` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `questions`
--
ALTER TABLE `questions`
  ADD CONSTRAINT `fk_questions_question_category1` FOREIGN KEY (`question_category_id`) REFERENCES `question_category` (`id`),
  ADD CONSTRAINT `fk_questions_surv_survey_language1` FOREIGN KEY (`surv_survey_language_id`) REFERENCES `surv_survey_language` (`id`);

--
-- Constraints for table `question_answers`
--
ALTER TABLE `question_answers`
  ADD CONSTRAINT `fk_question_answers_questions1` FOREIGN KEY (`questions_id`) REFERENCES `questions` (`id`);

--
-- Constraints for table `surv_panel_labels_questions`
--
ALTER TABLE `surv_panel_labels_questions`
  ADD CONSTRAINT `fk_surv_panel_labels_questions_surv_survey_panels1` FOREIGN KEY (`surv_survey_panels_id`) REFERENCES `surv_survey_panels` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `surv_panel_questions`
--
ALTER TABLE `surv_panel_questions`
  ADD CONSTRAINT `fk_surv_panel_questions_questions1` FOREIGN KEY (`questions_id`) REFERENCES `questions` (`id`),
  ADD CONSTRAINT `fk_surv_panel_questions_surv_survey_panels1` FOREIGN KEY (`surv_survey_panels_id`) REFERENCES `surv_survey_panels` (`id`),
  ADD CONSTRAINT `surv_panel_questions_ibfk_1` FOREIGN KEY (`surv_panel_labels_questions_id`) REFERENCES `surv_panel_labels_questions` (`id`);

--
-- Constraints for table `surv_survey_has_surv_survey_language`
--
ALTER TABLE `surv_survey_has_surv_survey_language`
  ADD CONSTRAINT `fk_surv_survey_has_surv_survey_language_surv_survey1` FOREIGN KEY (`surv_survey_id`) REFERENCES `surv_survey` (`id`),
  ADD CONSTRAINT `fk_surv_survey_has_surv_survey_language_surv_survey_language1` FOREIGN KEY (`surv_survey_language_id`) REFERENCES `surv_survey_language` (`id`);

--
-- Constraints for table `surv_survey_panels`
--
ALTER TABLE `surv_survey_panels`
  ADD CONSTRAINT `fk_surv_survey_panels_surv_survey1` FOREIGN KEY (`surv_survey_id`) REFERENCES `surv_survey` (`id`);

--
-- Constraints for table `user_credentials`
--
ALTER TABLE `user_credentials`
  ADD CONSTRAINT `user_credentials_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `pharmacist` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
